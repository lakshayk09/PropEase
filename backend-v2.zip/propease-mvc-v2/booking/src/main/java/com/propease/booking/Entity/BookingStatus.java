package com.propease.booking.Entity;

public enum BookingStatus {
    initiated,
    pending,
    confirmed,
    cancelled      // Booking was cancelled by user
}

