package com.propease.booking.Exception;

import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(FeignException.class)
    public ResponseEntity<Map<String, Object>> handleFeignException(FeignException ex) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now());
        errorResponse.put("status", ex.status());

        switch (ex.status()) {
            case 404:
                errorResponse.put("message", "Required service or resource not found");
                return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
            case 500:
                errorResponse.put("message", "External service unavailable");
                return new ResponseEntity<>(errorResponse, HttpStatus.SERVICE_UNAVAILABLE);
            default:
                errorResponse.put("message", "External service error: " + ex.getMessage());
                return new ResponseEntity<>(errorResponse, HttpStatus.valueOf(ex.status()));
        }
    }

}