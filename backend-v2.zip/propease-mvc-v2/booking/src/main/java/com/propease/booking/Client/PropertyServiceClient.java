package com.propease.booking.Client;

import com.propease.booking.dto.PropertyDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

@FeignClient(name = "property-service", url = "${property.service.url:http://localhost:8090}")
public interface PropertyServiceClient {

    @GetMapping("/api/properties/{propertyId}")
    ResponseEntity<PropertyDTO> getProperty(@PathVariable("propertyId") int propertyId);

    @GetMapping("/api/properties/user")
    ResponseEntity<List<PropertyDTO>> getPropertiesAddedByOwner();
}