package com.propease.booking.Service;

import com.propease.booking.dto.BookingDTO;
import com.propease.booking.Entity.BookingStatus;
import com.propease.booking.dto.PropertyDTO;

import java.util.List;

public interface BookingService {

    // Basic CRUD operations
    List<BookingDTO> findAll();

    BookingDTO findById(int id);

    BookingDTO save(BookingDTO bookingDTO);

    void deleteById(int id);

    // Booking-specific operations
    List<BookingDTO> findBookingsByUserId(Long userId);

    List<BookingDTO> findBookingsByPropertyId(Long propertyId);

//    List<BookingDTO> findUpcomingBookings(Long userId);

    // Availability check
//    boolean isPropertyAvailable(Long propertyId, LocalDate startDate, LocalDate endDate);

    // Booking status management
    BookingDTO updateBookingStatus(Integer bookingId, String status);

    // For Payment integration
    BookingDTO updatePaymentDetails(Integer bookingId, String paymentId, String paymentStatus);

    // Booking cancellation
    BookingDTO cancelBooking(Integer bookingId, String reason);


}