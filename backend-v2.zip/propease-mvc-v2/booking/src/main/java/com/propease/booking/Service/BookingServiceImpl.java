package com.propease.booking.Service;

import com.propease.booking.Client.PropertyServiceClient;
import com.propease.booking.Client.UserServiceClient;
import com.propease.booking.Entity.Booking;
import com.propease.booking.Exception.BookingBadRequestException;
import com.propease.booking.Exception.BookingNotFoundException;
import com.propease.booking.Exception.PropertyNotFoundException;
import com.propease.booking.Exception.UserNotFoundException;
import com.propease.booking.dto.BookingDTO;
import com.propease.booking.Entity.BookingStatus;
import com.propease.booking.Repository.BookingRepo;
import com.propease.booking.dto.PropertyDTO;
import com.propease.booking.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepo bookingRepo;
    private final PropertyServiceClient propertyServiceClient;
    private final UserServiceClient userServiceClient;
    private final BookingUtil bookingUtil;

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Autowired
    public BookingServiceImpl(BookingRepo bookingRepo, PropertyServiceClient propertyServiceClient,
                              UserServiceClient userServiceClient, BookingUtil bookingUtil) {
        this.bookingRepo = bookingRepo;
        this.propertyServiceClient = propertyServiceClient;
        this.userServiceClient = userServiceClient;
        this.bookingUtil = bookingUtil;
    }

    @Override
    public List<BookingDTO> findAll() {
        List<Booking> bookings = bookingRepo.findAll();
        return bookingUtil.mapEntityToDTOList(bookings);
    }

    @Override
    public BookingDTO findById(int id) {
        Optional<Booking> result = bookingRepo.findById(id);

        if (result.isPresent()) {
            Booking booking = result.get();
            return bookingUtil.mapEntityToDTO(booking);
        } else {
            throw new BookingNotFoundException("Did not find booking with id - " + id);
        }
    }

    @Override
    @Transactional
    public BookingDTO save(BookingDTO bookingDTO) {
        // Get the username of the logged-in user for the current booking
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new UserNotFoundException("Current user not found while creating booking");
        }

        UserDTO currentUser = userResponse.getBody();

        if(bookingDTO.getBookingStatus() != null && bookingDTO.getBookingStatus().equals("cancelled")) {
            throw new BookingBadRequestException("Booking has already been cancelled");
        }

        // Validate property exists
        ResponseEntity<PropertyDTO> propertyResponse = propertyServiceClient.getProperty(bookingDTO.getPropertyId().intValue());
        if (!propertyResponse.getStatusCode().is2xxSuccessful() || propertyResponse.getBody() == null) {
            throw new PropertyNotFoundException("Property not found with ID: " + bookingDTO.getPropertyId());
        }

        PropertyDTO property = propertyResponse.getBody();

        // Convert DTO to entity
        Booking booking = new Booking();

        if (bookingDTO.getId() != null) {
            booking.setId(bookingDTO.getId());
        }

        // Check if the property is available for the specified dates
        LocalDate startDate = LocalDate.parse(bookingDTO.getStartDate(), formatter);
        LocalDate endDate = LocalDate.parse(bookingDTO.getEndDate(), formatter);

        // Check if the start date is before today
        if (startDate.isBefore(LocalDate.now())) {
            throw new BookingBadRequestException("Booking start date cannot be in the past.");
        }


        // Set booking attributes
        booking.setProperty(bookingDTO.getPropertyId());
        booking.setUser(currentUser.getId());
        booking.setBookingDate(LocalDate.now());
        booking.setStartDate(startDate);
        booking.setEndDate(endDate);
        booking.setBookingAmount(bookingDTO.getBookingAmount());

        // For new bookings, set status to INITIATED if not provided
        if (bookingDTO.getId() == null && bookingDTO.getBookingStatus() == null) {
            booking.setBookingStatus(BookingStatus.initiated);
        } else {
            booking.setBookingStatus(BookingStatus.valueOf(bookingDTO.getBookingStatus()));
        }

        booking.setPaymentId(bookingDTO.getPaymentId());
        booking.setPaymentStatus(bookingDTO.getPaymentStatus());
        booking.setSpecialRequests(bookingDTO.getSpecialRequests());
        booking.setGuestCount(bookingDTO.getGuestCount());

        // Save the booking
        Booking savedBooking = bookingRepo.save(booking);

        return bookingUtil.mapEntityToDTO(savedBooking);
    }

    @Override
    public void deleteById(int id) {
        bookingRepo.deleteById(id);
    }

    @Override
    public List<BookingDTO> findBookingsByUserId(Long userId) {
        List<Booking> bookings = bookingRepo.findByUserId(userId);
        return bookingUtil.mapEntityToDTOList(bookings);
    }

    @Override
    public List<BookingDTO> findBookingsByPropertyId(Long propertyId) {
        List<Booking> bookings = bookingRepo.findByPropertyId(propertyId);
        return bookingUtil.mapEntityToDTOList(bookings);
    }


    @Override
    @Transactional
    public BookingDTO updateBookingStatus(Integer bookingId, String status) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + bookingId));

        if(status.equals("confirmed"))
            booking.setBookingStatus(BookingStatus.confirmed);
        else if(status.equals("cancelled"))
            booking.setBookingStatus(BookingStatus.cancelled);

        Booking updatedBooking = bookingRepo.save(booking);

        return bookingUtil.mapEntityToDTO(updatedBooking);
    }



    @Override
    @Transactional
    public BookingDTO updatePaymentDetails(Integer bookingId, String paymentId, String paymentStatus) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + bookingId));

        booking.setPaymentId(paymentId);
        booking.setPaymentStatus(paymentStatus);

        // If payment was successful, update booking status
        if ("COMPLETED".equals(paymentStatus) || "SUCCESS".equals(paymentStatus)) {
            booking.setBookingStatus(BookingStatus.confirmed);
        }

        Booking updatedBooking = bookingRepo.save(booking);
        return bookingUtil.mapEntityToDTO(updatedBooking);
    }

    @Override
    @Transactional
    public BookingDTO cancelBooking(Integer bookingId, String reason) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + bookingId));

        booking.setBookingStatus(BookingStatus.cancelled);

        Booking updatedBooking = bookingRepo.save(booking);
        return bookingUtil.mapEntityToDTO(updatedBooking);
    }
}