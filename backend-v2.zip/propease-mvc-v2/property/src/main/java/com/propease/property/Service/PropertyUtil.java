package com.propease.property.Service;


import com.propease.property.Client.UserServiceClient;
import com.propease.property.Entity.*;
import com.propease.property.Repository.FeatureRepo;
import com.propease.property.dto.PropertyDTO;
import com.propease.property.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class PropertyUtil {

    private final FeatureRepo featureRepo;
    private final UserServiceClient userServiceClient;

    @Autowired
    public PropertyUtil(FeatureRepo featureRepo, UserServiceClient userServiceClient) {
        this.featureRepo = featureRepo;
        this.userServiceClient = userServiceClient;
    }


    public PropertyDTO mapEntityToDTO(Property property) {

        PropertyDTO dto = new PropertyDTO();

        dto.setId(property.getId());
        dto.setName(property.getName());
        dto.setAddress(property.getAddress());
        dto.setStatus(property.getStatus().toString());
        dto.setType(property.getType().toString());
        dto.setCity(property.getCity());
        dto.setState(property.getState());
        dto.setContactNumber(property.getContactNumber());
        dto.setPrice(property.getPrice());
        dto.setRooms(property.getRooms());
        dto.setImageUrl(property.getImageUrl());
        dto.setAddedBy(property.getAddedBy()); // set the id
        dto.setFeatureIds(property.getFeatures().stream()
                .map(Feature::getId)
                .collect(Collectors.toSet()));

        return dto;
    }

    public List<PropertyDTO> mapEntityToDTOList(List<Property> properties) {
        return properties.stream().map(this::mapEntityToDTO).toList();
    }

    public Property mapDTOToEntity(PropertyDTO propertyDTO) {
        Property property = new Property();
        if(propertyDTO.getId() != null) {
            property.setId(propertyDTO.getId());
        }
        property.setName(propertyDTO.getName());
        property.setAddress(propertyDTO.getAddress());
        property.setStatus(PropertyStatus.valueOf(propertyDTO.getStatus()));
        property.setType(PropertyType.valueOf(propertyDTO.getType()));
        property.setCity(propertyDTO.getCity());
        property.setState(propertyDTO.getState());
        property.setContactNumber(propertyDTO.getContactNumber());
        property.setPrice(propertyDTO.getPrice());
        property.setRooms(propertyDTO.getRooms());
        property.setImageUrl(propertyDTO.getImageUrl());

        property.setAddedBy(propertyDTO.getAddedBy());

        Set<Feature> featureSet = propertyDTO.getFeatureIds()
                .stream()
                .map(id -> featureRepo.findById(id).orElseThrow())
                .collect(Collectors.toSet());

        property.setFeatures(featureSet);

        return property;
    }

}

