package com.propease.property.Entity;

public enum PropertyType {

    apartment,

    pg,

    house;
}