package com.propease.auth2.Controller;

import com.propease.auth2.Entity.Role;
import com.propease.auth2.Service.AuthServiceImpl;
import com.propease.auth2.dto.LoginRequest;
import com.propease.auth2.dto.LoginResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoginControllerTest {

    @Mock
    private AuthServiceImpl authService;

    @InjectMocks
    private LoginController loginController;

    private LoginRequest loginRequest;
    private LoginResponse loginResponse;

    @BeforeEach
    void setUp() {
        loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("password");

        loginResponse = new LoginResponse();
        loginResponse.setToken("mock-jwt-token");
        loginResponse.setUsername("testuser");
        loginResponse.setRole(Role.TENANT);
        loginResponse.setMessage("Login successful");
    }

    @Test
    void testLogin_Success() {
        // Given
        when(authService.login(loginRequest)).thenReturn(loginResponse);

        // When
        ResponseEntity<LoginResponse> response = loginController.login(loginRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("mock-jwt-token", response.getBody().getToken());
        assertEquals("testuser", response.getBody().getUsername());
        assertEquals("ROLE_TENANT", "ROLE_" + response.getBody().getRole());
        assertEquals("Login successful", response.getBody().getMessage());
        verify(authService).login(loginRequest);
    }

    @Test
    void testLogin_InvalidCredentials() {
        // Given
        LoginResponse errorResponse = new LoginResponse();
        errorResponse.setToken(null);
        errorResponse.setUsername(null);
        errorResponse.setRole(null);
        errorResponse.setMessage("Invalid credentials");

        when(authService.login(loginRequest)).thenReturn(errorResponse);

        // When
        ResponseEntity<LoginResponse> response = loginController.login(loginRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNull(response.getBody().getToken());
        assertEquals("Invalid credentials", response.getBody().getMessage());
        verify(authService).login(loginRequest);
    }

    @Test
    void testLogin_WithDifferentRoles() {
        // Given - Test with OWNER role
        LoginResponse ownerResponse = new LoginResponse();
        ownerResponse.setToken("owner-jwt-token");
        ownerResponse.setUsername("owner");
        ownerResponse.setRole(Role.OWNER);
        ownerResponse.setMessage("Login successful");

        LoginRequest ownerRequest = new LoginRequest();
        ownerRequest.setUsername("owner");
        ownerRequest.setPassword("password");

        when(authService.login(ownerRequest)).thenReturn(ownerResponse);

        // When
        ResponseEntity<LoginResponse> response = loginController.login(ownerRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ROLE_OWNER", "ROLE_" + response.getBody().getRole());
        assertEquals("owner", response.getBody().getUsername());
    }

    @Test
    void testLogin_WithAdminRole() {
        // Given - Test with ADMIN role
        LoginResponse adminResponse = new LoginResponse();
        adminResponse.setToken("admin-jwt-token");
        adminResponse.setUsername("admin");
        adminResponse.setRole(Role.ADMIN);
        adminResponse.setMessage("Login successful");

        LoginRequest adminRequest = new LoginRequest();
        adminRequest.setUsername("admin");
        adminRequest.setPassword("adminpass");

        when(authService.login(adminRequest)).thenReturn(adminResponse);

        // When
        ResponseEntity<LoginResponse> response = loginController.login(adminRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ROLE_ADMIN", "ROLE_" + response.getBody().getRole());
        assertEquals("admin", response.getBody().getUsername());
    }

    @Test
    void testLogin_ServiceThrowsException() {
        // Given
        when(authService.login(loginRequest)).thenThrow(new RuntimeException("Authentication failed"));

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> loginController.login(loginRequest));

        assertEquals("Authentication failed", exception.getMessage());
        verify(authService).login(loginRequest);
    }

    @Test
    void testLogin_EmptyCredentials() {
        // Given
        LoginRequest emptyRequest = new LoginRequest();
        emptyRequest.setUsername("");
        emptyRequest.setPassword("");

        LoginResponse emptyResponse = new LoginResponse();
        emptyResponse.setMessage("Username and password are required");

        when(authService.login(emptyRequest)).thenReturn(emptyResponse);

        // When
        ResponseEntity<LoginResponse> response = loginController.login(emptyRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Username and password are required", response.getBody().getMessage());
    }

    @Test
    void testLogin_NullCredentials() {
        // Given
        LoginRequest nullRequest = new LoginRequest();
        nullRequest.setUsername(null);
        nullRequest.setPassword(null);

        LoginResponse nullResponse = new LoginResponse();
        nullResponse.setMessage("Invalid request");

        when(authService.login(nullRequest)).thenReturn(nullResponse);

        // When
        ResponseEntity<LoginResponse> response = loginController.login(nullRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Invalid request", response.getBody().getMessage());
    }
}