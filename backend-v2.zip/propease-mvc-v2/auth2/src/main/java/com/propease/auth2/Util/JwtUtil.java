package com.propease.auth2.Util;

import org.springframework.stereotype.Component;
import java.util.Date;

import org.springframework.stereotype.Component;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {

    private final String jwtsecret = "yoursecretkey012345678901234567890123456789"; // 256-bit key
    private final long jwtExpiration = 10 * 24 * 60 * 1000; // 24 hours

    public String generateToken(String username, String role) {
        Key key = new SecretKeySpec(jwtsecret.getBytes(), SignatureAlgorithm.HS256.getJcaName());
        return Jwts.builder()
                .setSubject(username)
                .claim("role", "ROLE_" + role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();

    }
}
