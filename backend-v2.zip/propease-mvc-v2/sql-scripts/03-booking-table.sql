USE `propease_directory2`;

DROP TABLE IF EXISTS `booking`;

CREATE TABLE `booking` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `booking_date` DATE NOT NULL,
  `check_in_date` DATE NOT NULL,
  `check_out_date` DATE NOT NULL,

  `booking_amount` DOUBLE NOT NULL,
  `booking_status` ENUM('pending', 'confirmed', 'cancelled') NOT NULL DEFAULT 'pending',
  `payment_id` VARCHAR(100),
  `payment_status` VARCHAR(50),
  `special_requests` TEXT,
  `guest_count` INT,

  `user_id` BIGINT NOT NULL,
  `property_id` BIGINT NOT NULL,

  PRIMARY KEY (`id`)
  
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;


INSERT INTO booking (
    booking_date, check_in_date, check_out_date,
    booking_amount, booking_status, payment_id, payment_status,
    special_requests, guest_count,
    user_id, property_id
)
VALUES
-- Property ID 1: Sunset Residency (price = 5000000) → 100% payment
(CURDATE(), '2025-06-01', '2025-06-05', 5000000, 'confirmed', 'PAY12345', 'SUCCESS', 'Near elevator', 2, 1, 1),

-- Property ID 2: Greenview PG (price = 8000) → 5% payment
(CURDATE(), '2025-06-10', '2025-06-20', 400, 'pending', NULL, NULL, 'Quiet room please', 1, 1, 2),

-- Property ID 3: Blue Lagoon Villas (price = 12000000) → 100% payment
(CURDATE(), '2025-07-01', '2025-07-10', 12000000, 'cancelled', 'PAY98765', 'SUCCESS', 'Late check-in', 4, 1, 3),

-- Property ID 4: Urban Heights (price = 30000) → 100% payment
(CURDATE(), '2025-08-15', '2025-08-18', 30000, 'confirmed', 'PAY45678', 'SUCCESS', '', 3, 1, 4),

-- Property ID 5: CozyNest PG (price = 7000) → 5% payment
(CURDATE(), '2025-09-01', '2025-09-15', 350, 'pending', NULL, NULL, 'Vegetarian food preferred', 1, 1, 5);
