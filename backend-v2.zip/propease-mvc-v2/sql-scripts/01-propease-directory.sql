CREATE DATABASE  IF NOT EXISTS `propease_directory2`;
USE `propease_directory2`;

DROP TABLE IF EXISTS `property`;

CREATE TABLE `property` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('for_sale', 'for_rent') DEFAULT 'for_rent',
  `type` ENUM('apartment', 'pg', 'house') DEFAULT NULL,
  `city` VARCHAR(45) DEFAULT NULL,
  `state` VARCHAR(45) DEFAULT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  `added_by` BIGINT DEFAULT NULL,
  `price` INT DEFAULT NULL,
  `rooms` INT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `feature`;

CREATE TABLE `feature` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `property_feature`;

CREATE TABLE `property_feature` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `property_id` BIGINT NOT NULL,
  `feature_id` BIGINT NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`property_id`) REFERENCES `property`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`feature_id`) REFERENCES `feature`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `feature` (`name`) VALUES
('AC'),
('Food Available'),
('Laundry'),
('Parking'),
('Refrigerator'),
('Gym'),
('Swimming Pool');


INSERT INTO `property` (`name`, `address`, `city`, `state`, `price`, `rooms`, `status`, `type`, `contact_number`, `added_by`) VALUES
('Sunset Residency', '45 Park Street', 'Mumbai', 'Maharashtra', 5000000, 3, 'for_sale', 'apartment', '9876543210', 2),
('Greenview PG', '12 Lake Road', 'Pune', 'Maharashtra', 8000, 1, 'for_rent', 'pg', '9876501234', 2),
('Blue Lagoon Villas', '88 Riverwalk', 'Bangalore', 'Karnataka', 12000000, 4, 'for_sale', 'house', '9876505678', 2),
('Urban Heights', '5 Green Blvd', 'Hyderabad', 'Telangana', 30000, 2, 'for_rent', 'apartment', '9876512345', 2),
('CozyNest PG', '77 Maple Avenue', 'Chennai', 'Tamil Nadu', 7000, 1, 'for_rent', 'pg', '9876523456', 2);


-- Sunset Residency has AC, Parking, Swimming Pool
INSERT INTO `property_feature` (`property_id`, `feature_id`) VALUES (1, 1), (1, 4), (1, 7);

-- Greenview PG has AC, Food Available, Laundry
INSERT INTO `property_feature` (`property_id`, `feature_id`) VALUES (2, 1), (2, 2), (2, 3);

-- Blue Lagoon Villas has AC, Parking, Refrigerator, Gym, Swimming Pool
INSERT INTO `property_feature` (`property_id`, `feature_id`) VALUES (3, 1), (3, 4), (3, 5), (3, 6), (3, 7);

-- Urban Heights has AC, Parking, Gym
INSERT INTO `property_feature` (`property_id`, `feature_id`) VALUES (4, 1), (4, 4), (4, 6);

-- CozyNest PG has AC, Food Available
INSERT INTO `property_feature` (`property_id`, `feature_id`) VALUES (5, 1), (5, 2);

