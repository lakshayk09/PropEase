package com.propease.user.Controller;

import com.propease.user.Entity.Role;
import com.propease.user.Entity.User;
import com.propease.user.Service.UserService;
import com.propease.user.dto.UserDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.User.UserBuilder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private User user;
    private Role role;

    @BeforeEach
    void setUp() {
        role = new Role();
        role.setId(1L);
        role.setName("ROLE_TENANT");

        user = new User();
        user.setId(1L);
        user.setUserName("testuser");
        user.setPassword("password");
        user.setRole(role);
    }

    @Test
    void testGetUserById_Success() {
        // Given
        when(userService.findUserById(1L)).thenReturn(user);

        // When
        ResponseEntity<UserDTO> response = userController.getUserById(1L);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
        assertEquals("testuser", response.getBody().getUserName());
        assertEquals("ROLE_TENANT", response.getBody().getRoleName());
        verify(userService).findUserById(1L);
    }

    @Test
    void testGetUserById_NotFound() {
        // Given
        when(userService.findUserById(1L)).thenReturn(null);

        // When
        ResponseEntity<UserDTO> response = userController.getUserById(1L);

        // Then
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        verify(userService).findUserById(1L);
    }

    @Test
    void testGetUserByUsername_Success() {
        // Given
        when(userService.findUserByUserName("testuser")).thenReturn(user);

        // When
        ResponseEntity<UserDTO> response = userController.getUserByUsername("testuser");

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
        assertEquals("testuser", response.getBody().getUserName());
        assertEquals("ROLE_TENANT", response.getBody().getRoleName());
        verify(userService).findUserByUserName("testuser");
    }

    @Test
    void testGetUserByUsername_NotFound() {
        // Given
        when(userService.findUserByUserName("nonexistent")).thenReturn(null);

        // When
        ResponseEntity<UserDTO> response = userController.getUserByUsername("nonexistent");

        // Then
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        verify(userService).findUserByUserName("nonexistent");
    }

    @Test
    void testLoadUserByUsername_Success() {
        // Given
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername("testuser")
                .password("password")
                .authorities("ROLE_TENANT")
                .build();

        when(userService.loadUserByUsername("testuser")).thenReturn(userDetails);

        // When
        UserDetails response = userController.loadUserByUsername("testuser");

        // Then
        assertNotNull(response);
        assertEquals("testuser", response.getUsername());
        assertEquals("password", response.getPassword());
        assertTrue(response.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_TENANT")));
        verify(userService).loadUserByUsername("testuser");
    }

    @Test
    void testUserDTOMapping() {
        // Given
        when(userService.findUserById(1L)).thenReturn(user);

        // When
        ResponseEntity<UserDTO> response = userController.getUserById(1L);

        // Then
        UserDTO userDTO = response.getBody();
        assertNotNull(userDTO);
        assertEquals(user.getId(), userDTO.getId());
        assertEquals(user.getUserName(), userDTO.getUserName());
        assertEquals(user.getRole().getName(), userDTO.getRoleName());
    }
}