package com.propease.user.Service;

import com.propease.user.Entity.Role;
import com.propease.user.Entity.User;
import com.propease.user.Entity.WebUser;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {

    User findUserByUserName(String userName);
    void save(WebUser webUser);
    User findUserById(Long userId);
    Role findRoleByName(String name);
}
