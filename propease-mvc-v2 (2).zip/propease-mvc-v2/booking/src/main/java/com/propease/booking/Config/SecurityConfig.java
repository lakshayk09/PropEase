package com.propease.booking.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

@Configuration
public class SecurityConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
//                        .requestMatchers("/api/bookings").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.GET, "/api/bookings").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.GET, "/api/bookings/{bookingId}").hasAnyRole("TENANT", "ADMIN")
                                .requestMatchers(HttpMethod.GET, "/api/bookings/user").hasRole("TENANT")
                                .requestMatchers(HttpMethod.GET, "/api/bookings/owner").permitAll()
                                .requestMatchers(HttpMethod.GET, "/api/bookings/property/{propertyId}").hasAnyRole("OWNER","ADMIN")
                                .requestMatchers(HttpMethod.POST, "/api/bookings").hasRole("TENANT")
                                .requestMatchers(HttpMethod.POST, "/api/bookings/{bookingId}/cancel").hasAnyRole("TENANT","ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/bookings/{bookingId}").hasAnyRole("TENANT", "ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/bookings/{bookingId}/status").hasAnyRole("OWNER", "ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/bookings/{bookingId}/payment").hasRole("TENANT")
                                .requestMatchers(HttpMethod.DELETE, "/api/bookings/{bookingId}").hasAnyRole("OWNER", "ADMIN")

                        .anyRequest().authenticated()
                )
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwt -> jwt
                                .jwtAuthenticationConverter(jwtAuthenticationConverter())
                        )
                );

        return http.build();
    }

    // If your claim is called "role" (not "authorities"), map it:
    @Bean
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter converter = new JwtGrantedAuthoritiesConverter();
        converter.setAuthoritiesClaimName("role");
        converter.setAuthorityPrefix(""); // already "ROLE_" in your token

        JwtAuthenticationConverter authConverter = new JwtAuthenticationConverter();
        authConverter.setJwtGrantedAuthoritiesConverter(converter);
        return authConverter;
    }


    @Bean
    public JwtDecoder jwtDecoder() {
        String secret = "yoursecretkey012345678901234567890123456789"; // Must match your auth service
        SecretKey key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
        return NimbusJwtDecoder.withSecretKey(key).build();
    }
}
