package com.propease.booking.Controller;

import com.propease.booking.Client.PropertyServiceClient;
import com.propease.booking.Client.UserServiceClient;
import com.propease.booking.dto.BookingDTO;
import com.propease.booking.Entity.BookingStatus;
import com.propease.booking.Service.BookingService;
import com.propease.booking.dto.PropertyDTO;
import com.propease.booking.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class BookingController {

    private final BookingService bookingService;
    private final UserServiceClient userServiceClient;
    private final PropertyServiceClient propertyServiceClient;

    @Autowired
    public BookingController(BookingService bookingService, UserServiceClient userServiceClient, PropertyServiceClient propertyServiceClient) {
        this.bookingService = bookingService;
        this.userServiceClient = userServiceClient;
        this.propertyServiceClient = propertyServiceClient;
    }

    @GetMapping("/bookings")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<BookingDTO>> getAllBookings() {
        List<BookingDTO> bookings = bookingService.findAll();
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    @GetMapping("/bookings/{bookingId}")
    @PreAuthorize("hasRole('TENANT') || hasRole('ADMIN')")
    public ResponseEntity<BookingDTO> getBooking(@PathVariable int bookingId) {
        BookingDTO bookingDTO = bookingService.findById(bookingId);

        // Check if the current user has access to this booking
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found");
        }

        UserDTO currentUser = userResponse.getBody();

        // Allow access if user is admin, or if the booking belongs to the current user
        if (currentUser.getRoleName().equals("ROLE_ADMIN") ||
                bookingDTO.getUserId().equals(currentUser.getId())) {
            return new ResponseEntity<>(bookingDTO, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }

    @GetMapping("/bookings/user")
    @PreAuthorize("hasRole('TENANT')")
    public ResponseEntity<List<BookingDTO>> getCurrentUserBookings() {
        // Get username of currently authenticated user
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        // Fetch User details using Feign client
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found in the database");
        }

        UserDTO user = userResponse.getBody();

        // Get bookings for this user
        List<BookingDTO> bookings = bookingService.findBookingsByUserId(user.getId());

        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    @GetMapping("/bookings/property/{propertyId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    public ResponseEntity<List<BookingDTO>> getBookingsByProperty(@PathVariable Long propertyId) {
        List<BookingDTO> bookings = bookingService.findBookingsByPropertyId(propertyId);
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

//    @GetMapping("/bookings/check-availability/{propertyId}")
//    public ResponseEntity<Boolean> checkAvailability(
//            @PathVariable Long propertyId,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
//
//        boolean isAvailable = bookingService.isPropertyAvailable(propertyId, startDate, endDate);
//        return new ResponseEntity<>(isAvailable, HttpStatus.OK);
//    }

    @GetMapping("/bookings/owner")
//    @PreAuthorize("hasRole('ROLE_OWNER')")
    public ResponseEntity<List<BookingDTO>> getBookingsForOwnerProperties() {
        // 1. Fetch all properties for current owner
        ResponseEntity<List<PropertyDTO>> response = propertyServiceClient.getPropertiesAddedByOwner();
        List<PropertyDTO> properties = response.getBody();

        if (properties == null || properties.isEmpty()) {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
        }



        // 2. Get property IDs
        List<Long> propertyIds = properties.stream()
                .map(p -> p.getId().longValue())
                .collect(Collectors.toList());

        // 3. Fetch bookings for each property ID
        List<BookingDTO> allBookings = new ArrayList<>();
        for (Long propertyId : propertyIds) {
            List<BookingDTO> bookings = bookingService.findBookingsByPropertyId(propertyId);
            allBookings.addAll(bookings);
        }

        // 4. Sort by booking date/time descending
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        allBookings.sort((b1, b2) -> {
            try {
                LocalDate d1 = LocalDate.parse(b1.getBookingDate(), formatter);
                LocalDate d2 = LocalDate.parse(b2.getBookingDate(), formatter);
                return d2.compareTo(d1); // newest first
            } catch (Exception e) {
                return 0; // fallback if date format is bad
            }
        });
        return new ResponseEntity<>(allBookings, HttpStatus.OK);
    }


    @PostMapping("/bookings")
    @PreAuthorize("hasRole('TENANT')")
    public ResponseEntity<BookingDTO> createBooking(@RequestBody BookingDTO bookingDTO) {
        bookingDTO.setId(null); // Ensure we're creating a new booking

        // Get current user from authentication context
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found while creating booking");
        }

        UserDTO userDTO = userResponse.getBody();
        bookingDTO.setUserId(userDTO.getId());
        bookingDTO.setUserName(userDTO.getUserName());

        // Validate property exists and get property details
        ResponseEntity<PropertyDTO> propertyResponse = propertyServiceClient.getProperty(bookingDTO.getPropertyId().intValue());

        if (!propertyResponse.getStatusCode().is2xxSuccessful() || propertyResponse.getBody() == null) {
            throw new RuntimeException("Property not found with ID: " + bookingDTO.getPropertyId());
        }

        PropertyDTO property = propertyResponse.getBody();
        bookingDTO.setPropertyName(property.getName());


        BookingDTO savedBooking = bookingService.save(bookingDTO);
        return new ResponseEntity<>(savedBooking, HttpStatus.CREATED);
    }

    @PutMapping("/bookings/{bookingId}")
    @PreAuthorize("hasAnyRole('TENANT','ADMIN')")
    public ResponseEntity<BookingDTO> updateBooking(@PathVariable int bookingId, @RequestBody BookingDTO bookingDTO) {
        // Ensure the ID in the path matches the DTO
        bookingDTO.setId(bookingId);

        // Get current user from authentication context for authorization
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found");
        }

        UserDTO currentUser = userResponse.getBody();

        // Get the existing booking to check ownership
        BookingDTO existingBooking = bookingService.findById(bookingId);

        // Only allow updates if user is admin or owns the booking
        if (!currentUser.getRoleName().equals("ROLE_ADMIN") &&
                !existingBooking.getUserId().equals(currentUser.getId())) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }

        BookingDTO updatedBooking = bookingService.save(bookingDTO);
        return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
    }

    @PutMapping("/bookings/{bookingId}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    public ResponseEntity<BookingDTO> updateBookingStatus(
            @PathVariable Integer bookingId,
            @RequestParam BookingStatus status) {

        BookingDTO updatedBooking = bookingService.updateBookingStatus(bookingId, status);
        return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
    }

    @PutMapping("/bookings/{bookingId}/payment")
    public ResponseEntity<BookingDTO> updatePaymentDetails(
            @PathVariable Integer bookingId,
            @RequestParam String paymentId,
            @RequestParam String paymentStatus) {

        BookingDTO updatedBooking = bookingService.updatePaymentDetails(bookingId, paymentId, paymentStatus);
        return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
    }

    @PutMapping("/bookings/{bookingId}/cancel")
    @PreAuthorize("hasRole('TENANT')")
    public ResponseEntity<BookingDTO> cancelBooking(
            @PathVariable Integer bookingId,
            @RequestBody Map<String, String> reason) {

        // Get current user from authentication context
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found");
        }

        UserDTO currentUser = userResponse.getBody();

        // Get the existing booking to check ownership
        BookingDTO existingBooking = bookingService.findById(bookingId);

        // Only allow cancellation if user is admin or owns the booking
        if (!currentUser.getRoleName().equals("ROLE_ADMIN") &&
                !existingBooking.getUserId().equals(currentUser.getId())) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }

        String cancellationReason = reason != null ? reason.get("reason") : "Cancelled by user";
        BookingDTO cancelledBooking = bookingService.cancelBooking(bookingId, cancellationReason);
        return new ResponseEntity<>(cancelledBooking, HttpStatus.OK);
    }

    @DeleteMapping("/bookings/{bookingId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deleteBooking(@PathVariable int bookingId) {
        // Check if booking exists
        bookingService.findById(bookingId);

        bookingService.deleteById(bookingId);
        return new ResponseEntity<>("Booking deleted successfully", HttpStatus.OK);
    }

//    @GetMapping("/bookings/user/{userId}/upcoming")
//    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
//    public ResponseEntity<List<BookingDTO>> getUpcomingBookings(@PathVariable Long userId) {
//        List<BookingDTO> upcomingBookings = bookingService.findUpcomingBookings(userId);
//        return new ResponseEntity<>(upcomingBookings, HttpStatus.OK);
//    }
}