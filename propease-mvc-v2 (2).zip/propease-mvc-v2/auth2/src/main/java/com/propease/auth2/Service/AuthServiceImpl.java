package com.propease.auth2.Service;

import com.propease.auth2.Entity.Role;
import com.propease.auth2.Entity.User;
import com.propease.auth2.Exception.UserAlreadyExistsException;
import com.propease.auth2.Repository.UserRepository;
import com.propease.auth2.Util.JwtUtil;
import com.propease.auth2.dto.LoginRequest;
import com.propease.auth2.dto.LoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService{

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private JwtUtil jwtUtil;

    @Autowired
    public AuthServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }


    @Override
    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new UserAlreadyExistsException(
                        "User not found with username or email or mobile number: " + request.getUsername()));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new UserAlreadyExistsException("Invalid password. Try again.");
        }

        Long roleId = user.getRoleId();

        Role role = null;
        String roleName = "";

        if(roleId == 1) {
            roleName = "TENANT";
            role = Role.TENANT;
        }
        else if(roleId == 2) {
            roleName = "OWNER";
            role = Role.OWNER;
        }
        else if (roleId == 3) {
            roleName = "ADMIN";
            role = Role.ADMIN;
        }


        String token = jwtUtil.generateToken(user.getUsername(), roleName);
        // Set the token in the response header (if needed)


        return new LoginResponse(token, user.getUsername(), "Login successful", role);
    }
}
