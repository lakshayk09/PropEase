package com.propease.property.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.propease.property.Client.UserServiceClient;
import com.propease.property.Service.PropertyService;
import com.propease.property.dto.PropertyDTO;
import com.propease.property.dto.UserDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class PropertyControllerTest {

    @Mock
    private PropertyService propertyService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private UserServiceClient userServiceClient;

    @InjectMocks
    private PropertyController propertyController;

    private MockMvc mockMvc;
    private PropertyDTO propertyDTO;
    private UserDTO userDTO;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(propertyController).build();

        // Setup test data
        propertyDTO = new PropertyDTO();
        propertyDTO.setId(1);
        propertyDTO.setName("Test Property");
        propertyDTO.setAddedBy(1L);

        userDTO = new UserDTO();
        userDTO.setId(1L);
        userDTO.setUserName("testuser");
        userDTO.setRoleName("ROLE_OWNER");

        // Setup security context
        UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken("testuser", "password");
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    void testFindAll_Success() {
        // Given
        List<PropertyDTO> properties = Arrays.asList(propertyDTO);
        when(propertyService.findAll()).thenReturn(properties);

        // When
        ResponseEntity<List<PropertyDTO>> response = propertyController.findAll();

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        assertEquals("Test Property", response.getBody().get(0).getName());
        verify(propertyService).findAll();
    }

    @Test
    void testGetProperty_Success() {
        // Given
        when(propertyService.findById(1)).thenReturn(propertyDTO);

        // When
        ResponseEntity<PropertyDTO> response = propertyController.getProperty(1);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Test Property", response.getBody().getName());
        verify(propertyService).findById(1);
    }

    @Test
    void testGetPropertiesAddedByOwner_Success() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(propertyService.getPropertiesByUserId(1L)).thenReturn(Arrays.asList(propertyDTO));

        // When
        ResponseEntity<List<PropertyDTO>> response = propertyController.getPropertiesAddedByOwner();

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(userServiceClient).getUserByUsername("testuser");
        verify(propertyService).getPropertiesByUserId(1L);
    }

    @Test
    void testGetPropertiesAddedByOwner_UserNotFound() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.notFound().build();
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> propertyController.getPropertiesAddedByOwner());

        assertEquals("Current user not found while fetching properties", exception.getMessage());
    }

    @Test
    void testGetPropertiesAddedByOwnerId_Success() {
        // Given
        when(propertyService.getPropertiesByUserId(1L)).thenReturn(Arrays.asList(propertyDTO));

        // When
        ResponseEntity<List<PropertyDTO>> response = propertyController.getPropertiesAddedByOwnerId(1L);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(propertyService).getPropertiesByUserId(1L);
    }

    @Test
    void testAddProperty_Success() {
        // Given
        PropertyDTO inputProperty = new PropertyDTO();
        inputProperty.setName("New Property");

        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(propertyService.save(any(PropertyDTO.class))).thenReturn(propertyDTO);

        // When
        ResponseEntity<PropertyDTO> response = propertyController.addProperty(inputProperty);

        // Then
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNull(inputProperty.getId()); // Should be set to null
        assertEquals(1L, inputProperty.getAddedBy()); // Should be set from user
        verify(propertyService).save(inputProperty);
    }

    @Test
    void testUpdateProperty_Success() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(propertyService.save(propertyDTO)).thenReturn(propertyDTO);

        // When
        PropertyDTO response = propertyController.updateProperty(propertyDTO);

        // Then
        assertNotNull(response);
        assertEquals(1L, propertyDTO.getAddedBy());
        verify(propertyService).save(propertyDTO);
    }

//    @Test
//    void testPatchProperty_Success() {
//        // Given
//        Map<String, Object> patchPayload = new HashMap<>();
//        patchPayload.put("name", "Updated Name");
//
//        when(propertyService.findById(1)).thenReturn(propertyDTO);
//        when(propertyService.save(any(PropertyDTO.class))).thenReturn(propertyDTO);
//
//        // When
//        PropertyDTO response = propertyController.patchProperty(1, patchPayload);
//
//        // Then
//        assertNotNull(response);
//        verify(propertyService).findById(1);
//        verify(propertyService).save(any(PropertyDTO.class));
//    }

//    @Test
//    void testPatchProperty_Success() {
//        // Given
//        Map<String, Object> patchPayload = new HashMap<>();
//        patchPayload.put("name", "Updated Name");
//
//        PropertyDTO propertyDTO = new PropertyDTO(); // Create a proper DTO instance
//        propertyDTO.setId(1);
//        propertyDTO.setName("Old Name");
//
//        when(propertyService.findById(1)).thenReturn(propertyDTO);
//        when(propertyService.save(any(PropertyDTO.class))).thenReturn(propertyDTO);
//
//        // When
//        PropertyDTO response = propertyController.patchProperty(1, patchPayload);
//
//        // Then
//        assertNotNull(response);
//        verify(propertyService).findById(1);
//        verify(propertyService).save(any(PropertyDTO.class));
//    }


    @Test
    void testDeleteProperty_Success() {
        // Given
        when(propertyService.findById(1)).thenReturn(propertyDTO);

        // When
        String response = propertyController.deleteProperty(1);

        // Then
        assertEquals("Deleted property with id - 1", response);
        verify(propertyService).findById(1);
        verify(propertyService).deleteById(1);
    }

    @Test
    void testDeleteProperty_PropertyNotFound() {
        // Given
        when(propertyService.findById(1)).thenReturn(null);

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> propertyController.deleteProperty(1));

        assertEquals("Property not found with id - 1", exception.getMessage());
        verify(propertyService, never()).deleteById(1);
    }
}