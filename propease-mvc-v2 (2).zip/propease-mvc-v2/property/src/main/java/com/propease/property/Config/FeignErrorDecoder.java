package com.propease.property.Config;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.stereotype.Component;

@Component
public class FeignErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {
        switch (response.status()) {
            case 404:
                return new RuntimeException("User not found");
            case 500:
                return new RuntimeException("User service is unavailable");
            default:
                return new RuntimeException("Error occurred while calling user service");
        }
    }
}
