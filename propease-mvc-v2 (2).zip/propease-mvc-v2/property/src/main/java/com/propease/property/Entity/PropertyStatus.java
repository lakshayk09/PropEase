package com.propease.property.Entity;

public enum PropertyStatus {

    for_sale,

    for_rent;
}

