package com.propease.property.dto;

public class UserDTO {
    private Long id;
    private String userName;
    private String roleName;

    public UserDTO() {
    }

    public UserDTO(Long id, String userName, String roleName) {
        this.id = id;
        this.userName = userName;
        this.roleName = roleName;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
