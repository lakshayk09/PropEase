package com.propease.property.dto;

import java.util.Set;

public class PropertyDTO {
    private Integer id;
    private String name;
    private String address;
    private String status;
    private String type;
    private String city;
    private String state;
    private String contactNumber;
    private Long addedBy;   //Long because User "id" is also Long
    private int price;
    private int rooms;
    private String imageUrl;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    private Set<Integer> featureIds;


    public PropertyDTO() {}

    public PropertyDTO(int id, String imageUrl, String name, String address, String status, String type, String city, String state, String contactNumber, int price, int rooms, Long addedBy, Set<Integer> featureIds) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.status = status;
        this.type = type;
        this.city = city;
        this.state = state;
        this.contactNumber = contactNumber;
        this.price = price;
        this.rooms = rooms;
        this.addedBy = addedBy;
        this.featureIds = featureIds;
        this.imageUrl = imageUrl;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    public Long getAddedBy() {
        return addedBy;
    }

    public void setAddedBy(Long addedBy) {
        this.addedBy = addedBy;
    }

    public Set<Integer> getFeatureIds() {
        return featureIds;
    }

    public void setFeatureIds(Set<Integer> featureIds) {
        this.featureIds = featureIds;
    }
}

