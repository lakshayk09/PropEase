package com.propease.property.Service;


import com.propease.property.dto.PropertyDTO;

import java.util.List;

public interface PropertyService {

    List<PropertyDTO> findAll();

    PropertyDTO findById(int theId);

    PropertyDTO save(PropertyDTO propertyDTO);

    void deleteById(int theId);

    List<PropertyDTO> getPropertiesByUserId(Long ownerId);

}
