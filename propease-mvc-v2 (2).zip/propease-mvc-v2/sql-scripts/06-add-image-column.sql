ALTER TABLE propease_directory2.property
ADD COLUMN image_url VARCHAR(255);

UPDATE propease_directory2.property
SET image_url = 'https://www.granit.co.uk/wp-content/uploads/2022/12/Housing_Kingston_5.jpg'
WHERE id = 1;

UPDATE propease_directory2.property
SET image_url = 'https://rickardluckin.co.uk/storage/cms/O3T7yQxT2xV4VkE2TymnKQme1ObFcRXSlESWeA6W.jpg'
WHERE id = 2;

UPDATE propease_directory2.property
SET image_url = 'https://torontolife.mblycdn.com/tl/resized/2024/10/w1280/Overview.jpg'
WHERE id = 3;

UPDATE propease_directory2.property
SET image_url = 'https://i0.wp.com/insyncinsurance.co.uk/wp-content/uploads/2024/02/pexels-photo-1029599.jpeg'
WHERE id = 4;

UPDATE propease_directory2.property
SET image_url = 'https://images.ctfassets.net/n2ifzifcqscw/1brlxdvQR7UyF5M9rTvJQW/188d837cdd36eb55fc8fa9abc11f70bf/second-home-vs-investment-property-hero.jpeg'
WHERE id = 5;