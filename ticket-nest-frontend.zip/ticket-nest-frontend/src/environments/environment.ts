export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:8222' // Update this URL to match your login service endpoint
  };
  
