import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NavbarComponent } from 'src/app/shared/navbar/navbar.component';
import { environment } from 'src/environments/environment';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent],
  selector: 'app-property-search',
  templateUrl: './property-search.component.html',
  styleUrls: ['./property-search.component.scss']
})
export class PropertySearchComponent implements OnInit {
  searchQuery = '';
  selectedCity = '';
  selectedState = '';

  cities = ['Mumbai', 'Pune', 'Delhi', 'Bengaluru'];
  states = ['Maharashtra', 'Karnataka', 'Delhi', 'Tamil Nadu'];

  properties: any[] = [];
  selectedProperty: any = null;
  startDate: string = '';
  endDate: string = '';
  specialRequests: string = '';
  guestCount: number = 1;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadProperties();
  }

  loadProperties(): void {
    const token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<any[]>(`${environment.apiBaseUrl}/api/properties`, { headers }).subscribe({
      next: (data) => {
        this.properties = data;
      },
      error: (err) => {
        console.error('Error loading properties:', err);
      }
    });
  }

  get filteredProperties() {
    return this.properties.filter(prop =>
      (!this.searchQuery || prop.name.toLowerCase().includes(this.searchQuery.toLowerCase())) &&
      (!this.selectedCity || prop.city === this.selectedCity) &&
      (!this.selectedState || prop.state === this.selectedState)
    );
  }

  openBookingPopup(prop: any) {
    this.selectedProperty = prop;
    this.startDate = '';
    this.endDate = '';
    this.specialRequests = '';
    this.guestCount = 1;
  }

  closePopup() {
    this.selectedProperty = null;
  }

  submitBooking() {
    if (!this.startDate || !this.endDate || !this.selectedProperty) return;

    const bookingPayload = {
      propertyId: this.selectedProperty.id,
      propertyName: this.selectedProperty.name,
      bookingDate: new Date().toISOString().split('T')[0],
      startDate: this.startDate,
      endDate: this.endDate,
      bookingAmount: 500.0,
      bookingStatus: 'pending',
      paymentId: 'null',
      paymentStatus: 'SUCCESS',
      specialRequests: this.specialRequests,
      guestCount: this.guestCount
    };

    const token = sessionStorage.getItem('token');
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });

    this.http.post(`${environment.apiBaseUrl}/api/bookings`, bookingPayload, { headers }).subscribe({
      next: (res) => {
        alert('Booking successful!');
        this.closePopup();
      },
      error: (err) => {
        console.error('Booking failed:', err);
        alert('Booking failed. Please try again.');
      }
    });
  }

  bookProperty(prop: any) {
    this.openBookingPopup(prop);
  }
}
