import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from 'src/app/shared/navbar/navbar.component';
import { environment } from 'src/environments/environment';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  username = '';
  password = '';

  constructor(private http: HttpClient, private router: Router) {}

  onLogin() {
  const payload = {
    username: this.username,
    password: this.password
  };

  this.http.post(`${environment.apiBaseUrl}/api/auth/login`, payload).subscribe({
    next: (response: any) => {
      console.log('Login successful:', response);

      // Save to sessionStorage
      sessionStorage.setItem('token', response.token);
      sessionStorage.setItem('username', response.username);
      sessionStorage.setItem('role', response.role);

      // Redirect to dashboard or home based on role
      if (response.role === 'TENANT') {
        Example: this.router.navigate(['/property-search']);
      } else if (response.role === 'OWNER') {
        Example: this.router.navigate(['/owner']);
      }
    },
    error: (error) => {
      console.error('Login failed:', error);
      // Show error message to user
    }
  });
}

}
