import { Component } from '@angular/core';

@Component({
  selector: 'app-property-list',
  imports: [],
  templateUrl: './property-list.component.html',
  styleUrl: './property-list.component.scss'
})
export class PropertyListComponent {

}
