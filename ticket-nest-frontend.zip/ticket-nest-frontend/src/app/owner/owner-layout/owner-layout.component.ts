import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { HeaderComponent } from '../header/header.component';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-owner-layout',
  imports: [SidebarComponent, HeaderComponent, RouterOutlet],
  templateUrl: './owner-layout.component.html',
  styleUrl: './owner-layout.component.scss'
})
export class OwnerLayoutComponent {

}
