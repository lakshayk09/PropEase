import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
})
export class SidebarComponent {
  constructor(private router: Router) {}

  logout() {
    // Add your logout logic here (e.g., clearing tokens)
    console.log('Logging out...');
    this.router.navigate(['/login']);
  }

  goTo(route: String){
    console.log('Naving out...');
this.router.navigate([route]);
  }
}
