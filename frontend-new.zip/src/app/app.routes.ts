import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { RegisterComponent } from './pages/register/register.component';
import { LoginComponent } from './pages/login/login.component';
import { PropertySearchComponent } from './tenant/property-search/property-search.component';
import { MyBookingsComponent } from './tenant/my-bookings/my-bookings.component';
export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
   { path: 'property-search', component: PropertySearchComponent},
   { path: 'my-bookings', component: MyBookingsComponent},
{ path: 'owner', loadChildren: () => import('./owner/owner.module').then(m => m.OwnerModule) }


  
  
];
