import { Component } from '@angular/core';

@Component({
  selector: 'app-add-property',
  imports: [],
  templateUrl: './add-property.component.html',
  styleUrl: './add-property.component.scss'
})
export class AddPropertyComponent {

}
