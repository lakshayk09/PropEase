import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({ providedIn: 'root' })
export class PropertyService {
  private baseUrl = 'http://localhost:8222/api/properties';

  constructor(private http: HttpClient) {}

  getAllProperties() {
    return this.http.get(`${this.baseUrl}`);
  }

  getPropertyById(id: number) {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
}
