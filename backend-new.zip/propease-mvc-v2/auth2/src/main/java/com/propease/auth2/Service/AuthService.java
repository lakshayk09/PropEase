package com.propease.auth2.Service;

import com.propease.auth2.dto.LoginRequest;
import com.propease.auth2.dto.LoginResponse;

public interface AuthService {

    LoginResponse login(LoginRequest loginRequest);
}
