package com.propease.auth2.Service;

import com.propease.auth2.Entity.Role;
import com.propease.auth2.Entity.User;
import com.propease.auth2.Exception.InvalidPasswordException;
import com.propease.auth2.Exception.UserNotFoundException;
import com.propease.auth2.Repository.UserRepository;
import com.propease.auth2.Util.JwtUtil;
import com.propease.auth2.dto.LoginRequest;
import com.propease.auth2.dto.LoginResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService{

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private JwtUtil jwtUtil;

    // private - every class should have it's own logger
    // static - all instances of this class must use the same logger
    // final - to prevent reassignment
    private static final Logger logger = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    public AuthServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }


    @Override
    public LoginResponse login(LoginRequest request) {

        logger.info("Login request received");

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> {
                    logger.error("User not found with username: {}", request.getUsername());
                    return new UserNotFoundException(
                            "User not found with username: " + request.getUsername() + ". Please create an account.");
                });


        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            logger.error("Provided password doesn't match the user password");
            throw new InvalidPasswordException("Invalid password. Try again.");
        }

        Long roleId = user.getRoleId();

        Role role = null;
        String roleName = "";

        if(roleId == 1) {
            roleName = "TENANT";
            role = Role.TENANT;
        }
        else if(roleId == 2) {
            roleName = "OWNER";
            role = Role.OWNER;
        }
        else if (roleId == 3) {
            roleName = "ADMIN";
            role = Role.ADMIN;
        }


        String token = jwtUtil.generateToken(user.getUsername(), roleName);
        // Set the token in the response header (if needed)


        logger.info("Login successful, response generated.");
        return new LoginResponse(token, user.getUsername(), "Login successful", role);
    }
}
