package com.propease.auth2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Auth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
