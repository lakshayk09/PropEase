package com.propease.user.Service;

import com.propease.user.Entity.Role;
import com.propease.user.Entity.User;
import com.propease.user.Entity.WebUser;
import com.propease.user.Repository.RoleRepo;
import com.propease.user.Repository.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepo userRepo;

    @Mock
    private RoleRepo roleRepo;

    @Mock
    private BCryptPasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    private User testUser;
    private Role testRole;
    private WebUser testWebUser;

    @BeforeEach
    void setUp() {
        testRole = new Role();
        testRole.setName("TENANT");

        testUser = new User();
        testUser.setId(1L);
        testUser.setUserName("testuser");
        testUser.setPassword("encodedPassword");
        testUser.setRole(testRole);

        testWebUser = new WebUser();
        testWebUser.setUserName("newuser");
        testWebUser.setPassword("password123");
        testWebUser.setRoleName("TENANT");
    }

    @Test
    void findUserByUserName_Success() {
        // Arrange
        when(userRepo.findByUserName("testuser")).thenReturn(testUser);

        // Act
        User result = userService.findUserByUserName("testuser");

        // Assert
        assertNotNull(result);
        assertEquals(testUser, result);
        assertEquals("testuser", result.getUserName());
        verify(userRepo).findByUserName("testuser");
    }

    @Test
    void findUserByUserName_NotFound() {
        // Arrange
        when(userRepo.findByUserName("nonexistent")).thenReturn(null);

        // Act
        User result = userService.findUserByUserName("nonexistent");

        // Assert
        assertNull(result);
        verify(userRepo).findByUserName("nonexistent");
    }

    @Test
    void findUserById_Success() {
        // Arrange
        when(userRepo.findById(1)).thenReturn(Optional.of(testUser));

        // Act
        User result = userService.findUserById(1L);

        // Assert
        assertNotNull(result);
        assertEquals(testUser, result);
        assertEquals(1, result.getId());
        verify(userRepo).findById(1);
    }

    @Test
    void findUserById_NotFound() {
        // Arrange
        when(userRepo.findById(999)).thenReturn(Optional.empty());

        // Act
        User result = userService.findUserById(999L);

        // Assert
        assertNull(result);
        verify(userRepo).findById(999);
    }

    @Test
    void save_Success() {
        // Arrange
        when(passwordEncoder.encode("password123")).thenReturn("encodedPassword123");
        when(roleRepo.findByName("TENANT")).thenReturn(testRole);
        when(userRepo.save(any(User.class))).thenReturn(testUser);

        // Act
        userService.save(testWebUser);

        // Assert
        verify(passwordEncoder).encode("password123");
        verify(roleRepo).findByName("TENANT");
        verify(userRepo).save(any(User.class));
    }

    @Test
    void save_WithDifferentRole() {
        // Arrange
        Role ownerRole = new Role();
        ownerRole.setName("OWNER");

        testWebUser.setRoleName("OWNER");

        when(passwordEncoder.encode("password123")).thenReturn("encodedPassword123");
        when(roleRepo.findByName("OWNER")).thenReturn(ownerRole);
        when(userRepo.save(any(User.class))).thenReturn(testUser);

        // Act
        userService.save(testWebUser);

        // Assert
        verify(passwordEncoder).encode("password123");
        verify(roleRepo).findByName("OWNER");
        verify(userRepo).save(any(User.class));
    }

    @Test
    void findRoleByName_Success() {
        // Arrange
        when(roleRepo.findByName("TENANT")).thenReturn(testRole);

        // Act
        Role result = userService.findRoleByName("TENANT");

        // Assert
        assertNotNull(result);
        assertEquals(testRole, result);
        assertEquals("TENANT", result.getName());
        verify(roleRepo).findByName("TENANT");
    }

    @Test
    void findRoleByName_NotFound() {
        // Arrange
        when(roleRepo.findByName("NONEXISTENT")).thenReturn(null);

        // Act
        Role result = userService.findRoleByName("NONEXISTENT");

        // Assert
        assertNull(result);
        verify(roleRepo).findByName("NONEXISTENT");
    }

    @Test
    void loadUserByUsername_Success() {
        // Arrange
        when(userRepo.findByUserName("testuser")).thenReturn(testUser);

        // Act
        UserDetails result = userService.loadUserByUsername("testuser");

        // Assert
        assertNotNull(result);
        assertEquals("testuser", result.getUsername());
        assertEquals("encodedPassword", result.getPassword());
        assertEquals(1, result.getAuthorities().size());

        SimpleGrantedAuthority authority = (SimpleGrantedAuthority) result.getAuthorities().iterator().next();
        assertEquals("TENANT", authority.getAuthority());

        verify(userRepo).findByUserName("testuser");
    }

    @Test
    void loadUserByUsername_UserNotFound_ThrowsException() {
        // Arrange
        when(userRepo.findByUserName("nonexistent")).thenReturn(null);

        // Act & Assert
        UsernameNotFoundException exception = assertThrows(
                UsernameNotFoundException.class,
                () -> userService.loadUserByUsername("nonexistent")
        );

        assertEquals("Invalid username or password", exception.getMessage());
        verify(userRepo).findByUserName("nonexistent");
    }

    @Test
    void loadUserByUsername_WithOwnerRole() {
        // Arrange
        Role ownerRole = new Role();
        ownerRole.setName("OWNER");
        testUser.setRole(ownerRole);

        when(userRepo.findByUserName("testuser")).thenReturn(testUser);

        // Act
        UserDetails result = userService.loadUserByUsername("testuser");

        // Assert
        assertNotNull(result);
        assertEquals("testuser", result.getUsername());
        assertEquals(1, result.getAuthorities().size());

        SimpleGrantedAuthority authority = (SimpleGrantedAuthority) result.getAuthorities().iterator().next();
        assertEquals("OWNER", authority.getAuthority());

        verify(userRepo).findByUserName("testuser");
    }

    @Test
    void loadUserByUsername_WithAdminRole() {
        // Arrange
        Role adminRole = new Role();
        adminRole.setName("ADMIN");
        testUser.setRole(adminRole);

        when(userRepo.findByUserName("testuser")).thenReturn(testUser);

        // Act
        UserDetails result = userService.loadUserByUsername("testuser");

        // Assert
        assertNotNull(result);
        assertEquals("testuser", result.getUsername());
        assertEquals(1, result.getAuthorities().size());

        SimpleGrantedAuthority authority = (SimpleGrantedAuthority) result.getAuthorities().iterator().next();
        assertEquals("ADMIN", authority.getAuthority());

        verify(userRepo).findByUserName("testuser");
    }

    @Test
    void save_VerifyUserFieldsSetCorrectly() {
        // Arrange
        when(passwordEncoder.encode("password123")).thenReturn("encodedPassword123");
        when(roleRepo.findByName("TENANT")).thenReturn(testRole);

        // Capture the user that gets saved
        when(userRepo.save(any(User.class))).thenAnswer(invocation -> {
            User savedUser = invocation.getArgument(0);
            assertEquals("newuser", savedUser.getUserName());
            assertEquals("encodedPassword123", savedUser.getPassword());
            assertEquals(testRole, savedUser.getRole());
            return savedUser;
        });

        // Act
        userService.save(testWebUser);

        // Assert
        verify(userRepo).save(any(User.class));
    }

    @Test
    void findUserById_WithLongConversion() {
        // Arrange
        when(userRepo.findById(123)).thenReturn(Optional.of(testUser));

        // Act
        User result = userService.findUserById(123L);

        // Assert
        assertNotNull(result);
        assertEquals(testUser, result);
        verify(userRepo).findById(123);
    }
}