package com.propease.user.Controller;

import com.propease.user.Entity.Role;
import com.propease.user.Entity.User;
import com.propease.user.Entity.WebUser;
import com.propease.user.Exception.InvalidRoleException;
import com.propease.user.Exception.UsernameAlreadyExistsException;
import com.propease.user.Service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RegistrationControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private RegistrationController registrationController;

    private WebUser webUser;
    private User existingUser;
    private Role validRole;

    @BeforeEach
    void setUp() {
        webUser = new WebUser();
        webUser.setUserName("newuser");
        webUser.setPassword("password");
        webUser.setRoleName("ROLE_TENANT");

        existingUser = new User();
        existingUser.setId(1L);
        existingUser.setUserName("existinguser");

        validRole = new Role();
        validRole.setId(1L);
        validRole.setName("ROLE_TENANT");
    }

    @Test
    void testRegisterUser_Success() {
        // Given
        when(userService.findUserByUserName("newuser")).thenReturn(null);
        when(userService.findRoleByName("ROLE_TENANT")).thenReturn(validRole);

        // When
        ResponseEntity response = registrationController.registerUser(webUser);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userService).findUserByUserName("newuser");
        verify(userService).findRoleByName("ROLE_TENANT");
        verify(userService).save(webUser);
    }

    @Test
    void testRegisterUser_UserAlreadyExists() {
        // Given
        when(userService.findUserByUserName("newuser")).thenReturn(existingUser);

//        // When
//        ResponseEntity response = registrationController.registerUser(webUser);
//
//        // Then
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("User name already exists.", response.getBody());

        assertThrows(UsernameAlreadyExistsException.class, () -> {
            registrationController.registerUser(webUser);
        });

        verify(userService).findUserByUserName("newuser");
        verify(userService, never()).save(any(WebUser.class));
    }

    @Test
    void testRegisterUser_InvalidRole() {
        // Given
        when(userService.findUserByUserName("newuser")).thenReturn(null);
        when(userService.findRoleByName("ROLE_TENANT")).thenReturn(null);

//        // When
//        ResponseEntity response = registrationController.registerUser(webUser);
//
//        // Then
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Invalid role.", response.getBody());

        assertThrows(InvalidRoleException.class, () -> {
            registrationController.registerUser(webUser);
        });

        verify(userService).findUserByUserName("newuser");
        verify(userService).findRoleByName("ROLE_TENANT");
        verify(userService, never()).save(any(WebUser.class));
    }

    @Test
    void testRegisterUser_WithDifferentRoles() {
        // Given - Test with OWNER role
        webUser.setRoleName("ROLE_OWNER");
        Role ownerRole = new Role();
        ownerRole.setId(2L);
        ownerRole.setName("ROLE_OWNER");

        when(userService.findUserByUserName("newuser")).thenReturn(null);
        when(userService.findRoleByName("ROLE_OWNER")).thenReturn(ownerRole);

        // When
        ResponseEntity response = registrationController.registerUser(webUser);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userService).findRoleByName("ROLE_OWNER");
        verify(userService).save(webUser);
    }

    @Test
    void testRegisterUser_EmptyUsername() {
        // Given
        webUser.setUserName("");
        when(userService.findUserByUserName("")).thenReturn(null);
        when(userService.findRoleByName("ROLE_TENANT")).thenReturn(validRole);

        // When
        ResponseEntity response = registrationController.registerUser(webUser);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userService).save(webUser);
    }

    @Test
    void testRegisterUser_NullUsername() {
        // Given
        webUser.setUserName(null);
        when(userService.findUserByUserName(null)).thenReturn(null);
        when(userService.findRoleByName("ROLE_TENANT")).thenReturn(validRole);

        // When
        ResponseEntity response = registrationController.registerUser(webUser);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userService).save(webUser);
    }
}