package com.propease.user.Repository;

import com.propease.user.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, Integer> {

    // parameter must be "userName", not "username"
    User findByUserName(String userName);
}
