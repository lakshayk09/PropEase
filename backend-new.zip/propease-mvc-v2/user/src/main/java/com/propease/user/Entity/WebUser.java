package com.propease.user.Entity;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;


public class WebUser {

    @NotEmpty(message="Empty username not allowed")
    @Size(min=7, max=30, message = "Username length, min - 7, max - 30")
    @Pattern(regexp="[A-Z][a-z]{3,26}\\d{3}", message="Follow the username guidelines")
    private String userName;

    @NotEmpty(message = "Empty password not allowed")
    @Size(min=8, max=50, message = "Password length, min - 8, max - 50")
    private String password;

    @NotEmpty(message="Empty roleName not allowed")
    @Pattern(regexp="ROLE_TENANT|ROLE_OWNER", message = "Role must be either ROLE_TENANT or ROLE_OWNER")
    private String roleName;

    public WebUser() {

    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}

