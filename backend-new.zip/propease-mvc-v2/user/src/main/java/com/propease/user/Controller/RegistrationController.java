package com.propease.user.Controller;


import com.propease.user.Entity.Role;
import com.propease.user.Entity.User;
import com.propease.user.Exception.InvalidRoleException;
import com.propease.user.Exception.UsernameAlreadyExistsException;
import com.propease.user.Service.UserService;
import com.propease.user.Entity.WebUser;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Logger;

@RestController
@RequestMapping("/api/users")
@Validated
public class RegistrationController {

    private Logger logger = Logger.getLogger(getClass().getName());

    private final UserService userService;

    @Autowired
    public RegistrationController(UserService theUserService) {
        userService = theUserService;
    }

    @PostMapping("/register")
    @PreAuthorize("permitAll()")
    public ResponseEntity registerUser(@Valid @RequestBody WebUser theWebUser)  {
        String userName = theWebUser.getUserName();
        logger.info("Processing registration for: " + userName);

        // check the database if user already exists
        User user = userService.findUserByUserName(userName);
        if (user != null){
            logger.warning("User name already exists.");
            throw new UsernameAlreadyExistsException("Username already exists.");
        }

        // check the database if role is valid
        String roleName = theWebUser.getRoleName();
        Role role = userService.findRoleByName(roleName);
        if (role == null){
            String errorMsg = "Invalid role.";
            logger.warning(errorMsg);
            throw new InvalidRoleException("Invalid role");
        }

        // create user account and store in the database
        userService.save(theWebUser);

        return ResponseEntity.ok().build();
    }

}
