package com.propease.user.Service;

import com.propease.user.Entity.Role;
import com.propease.user.Entity.User;
import com.propease.user.Entity.WebUser;
import com.propease.user.Repository.RoleRepo;
import com.propease.user.Repository.UserRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepo userRepo;
    private final RoleRepo roleRepo;
    private final BCryptPasswordEncoder passwordEncoder;


    @Autowired
    public UserServiceImpl(UserRepo userRepo, RoleRepo roleRepo, BCryptPasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.roleRepo = roleRepo;
        this.passwordEncoder = passwordEncoder;
    }


    @Override
    public User findUserByUserName(String userName) {
        return userRepo.findByUserName(userName);
    }

    @Override
    public User findUserById(Long userId) {
        Optional<User> user = userRepo.findById(userId.intValue());
        return user.orElse(null);
    }

    @Override
    public void save(WebUser webUser) {

        log.info("User registration request received");

        User user = new User();

        user.setUserName(webUser.getUserName());
        user.setPassword(passwordEncoder.encode(webUser.getPassword()));
        user.setRole( roleRepo.findByName( webUser.getRoleName() ) );

        log.info("User successfully registered");
        userRepo.save(user);
    }

    @Override
    public Role findRoleByName(String name) {
        return roleRepo.findByName(name);
    }

    // login
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        log.info("Fetching user with username - {}", username);
        User user = userRepo.findByUserName(username);

        if(user == null){
            log.error("User not found");
            throw new UsernameNotFoundException("Invalid username or password");
        }

        SimpleGrantedAuthority sga = new SimpleGrantedAuthority(user.getRole().getName());

        log.info("User fetched successfully");
        return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), List.of(sga));
    }
}
