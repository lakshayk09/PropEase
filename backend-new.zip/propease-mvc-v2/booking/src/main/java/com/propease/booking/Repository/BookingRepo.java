package com.propease.booking.Repository;

import com.propease.booking.Entity.Booking;
import com.propease.booking.Entity.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BookingRepo extends JpaRepository<Booking, Integer> {

    // Find bookings for a specific property using property_id
    List<Booking> findByPropertyId(Long propertyId);

    // Find bookings made by a specific user using user_id
    List<Booking> findByUserId(Long userId);

    // Find bookings by status
    List<Booking> findByBookingStatus(BookingStatus status);

    // Find overlapping bookings for availability checking
//    @Query("SELECT b FROM Booking b WHERE b.property_id = :propertyId " +
//            "AND b.bookingStatus NOT IN ('cancelled') " +
//            "AND ((b.startDate BETWEEN :startDate AND :endDate) " +
//            "OR (b.endDate BETWEEN :startDate AND :endDate) " +
//            "OR (:startDate BETWEEN b.startDate AND b.endDate))")
//    List<Booking> findOverlappingBookings(
//            @Param("propertyId") Long propertyId,
//            @Param("startDate") LocalDate startDate,
//            @Param("endDate") LocalDate endDate);

    // Find upcoming bookings for a user
//    @Query("SELECT b FROM Booking b WHERE b.user_id = :userId " +
//            "AND b.startDate > :now " +
//            "AND b.bookingStatus NOT IN ('cancelled') " +
//            "ORDER BY b.startDate ASC")
//    List<Booking> findUpcomingBookingsForUser(
//            @Param("userId") Long userId,
//            @Param("now") LocalDate now);

    // Find bookings that need payment reminders
//    @Query("SELECT b FROM Booking b WHERE b.bookingStatus = 'confirmed' " +
//            "AND b.startDate BETWEEN :start AND :end")
//    List<Booking> findBookingsRequiringPaymentReminder(
//            @Param("start") LocalDate start,
//            @Param("end") LocalDate end);
}