package com.propease.booking.Config;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.stereotype.Component;

@Component
public class FeignErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {
        switch (response.status()) {
            case 404:
                if (methodKey.contains("getUserById") || methodKey.contains("getUserByUsername")) {
                    return new RuntimeException("User not found");
                } else if (methodKey.contains("getProperty")) {
                    return new RuntimeException("Property not found");
                }
                return new RuntimeException("Resource not found");
            case 500:
                if (methodKey.contains("getUserById") || methodKey.contains("getUserByUsername")) {
                    return new RuntimeException("User service is unavailable");
                } else if (methodKey.contains("getProperty")) {
                    return new RuntimeException("Property service is unavailable");
                }
                return new RuntimeException("Service is unavailable");
            default:
                return new RuntimeException("Error occurred while calling external service");
        }
    }
}