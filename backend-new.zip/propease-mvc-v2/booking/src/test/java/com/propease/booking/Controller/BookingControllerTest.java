package com.propease.booking.Controller;

import com.propease.booking.Client.PropertyServiceClient;
import com.propease.booking.Client.UserServiceClient;
import com.propease.booking.Entity.BookingStatus;
import com.propease.booking.Exception.ForbiddenRoleException;
import com.propease.booking.Service.BookingService;
import com.propease.booking.dto.BookingDTO;
import com.propease.booking.dto.PropertyDTO;
import com.propease.booking.dto.UserDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingControllerTest {

    @Mock
    private BookingService bookingService;

    @Mock
    private UserServiceClient userServiceClient;

    @Mock
    private PropertyServiceClient propertyServiceClient;

    @InjectMocks
    private BookingController bookingController;

    private BookingDTO bookingDTO;
    private UserDTO userDTO;
    private UserDTO adminUserDTO;
    private PropertyDTO propertyDTO;

    @BeforeEach
    void setUp() {
        // Setup test data
        bookingDTO = new BookingDTO();
        bookingDTO.setId(1);
        bookingDTO.setUserId(1L);
        bookingDTO.setUserName("testuser");
        bookingDTO.setPropertyId(1L);
        bookingDTO.setPropertyName("Test Property");
        bookingDTO.setStartDate(LocalDate.now().toString());
        bookingDTO.setEndDate(LocalDate.now().plusDays(5).toString());

        userDTO = new UserDTO();
        userDTO.setId(1L);
        userDTO.setUserName("testuser");
        userDTO.setRoleName("ROLE_TENANT");

        adminUserDTO = new UserDTO();
        adminUserDTO.setId(2L);
        adminUserDTO.setUserName("admin");
        adminUserDTO.setRoleName("ROLE_ADMIN");

        propertyDTO = new PropertyDTO();
        propertyDTO.setId(1);
        propertyDTO.setName("Test Property");

        // Setup security context
        UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken("testuser", "password");
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    void testGetAllBookings_Success() {
        // Given
        List<BookingDTO> bookings = Arrays.asList(bookingDTO);
        when(bookingService.findAll()).thenReturn(bookings);

        // When
        ResponseEntity<List<BookingDTO>> response = bookingController.getAllBookings();

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(bookingService).findAll();
    }

    @Test
    void testGetBooking_Success_AsOwner() {
        // Given
        when(bookingService.findById(1)).thenReturn(bookingDTO);
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

        // When
        ResponseEntity<BookingDTO> response = bookingController.getBooking(1);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getId());
        verify(bookingService).findById(1);
    }

    @Test
    void testGetBooking_Success_AsAdmin() {
        // Given
        BookingDTO otherUserBooking = new BookingDTO();
        otherUserBooking.setId(1);
        otherUserBooking.setUserId(999L); // Different user

        when(bookingService.findById(1)).thenReturn(otherUserBooking);
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(adminUserDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

        // When
        ResponseEntity<BookingDTO> response = bookingController.getBooking(1);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(bookingService).findById(1);
    }

    @Test
    void testGetBooking_Forbidden() {
        // Given
        BookingDTO otherUserBooking = new BookingDTO();
        otherUserBooking.setId(1);
        otherUserBooking.setUserId(999L); // Different user

        when(bookingService.findById(1)).thenReturn(otherUserBooking);
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

//        // When
//        ResponseEntity<BookingDTO> response = bookingController.getBooking(1);
//
//        // Then
//        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());

        // Then
        assertThrows(ForbiddenRoleException.class, () -> {
            // When
            bookingController.updateBooking(1, bookingDTO);
        });
    }

    @Test
    void testGetCurrentUserBookings_Success() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(bookingService.findBookingsByUserId(1L)).thenReturn(Arrays.asList(bookingDTO));

        // When
        ResponseEntity<List<BookingDTO>> response = bookingController.getCurrentUserBookings();

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(bookingService).findBookingsByUserId(1L);
    }

    @Test
    void testGetCurrentUserBookings_UserNotFound() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.notFound().build();
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> bookingController.getCurrentUserBookings());

        assertEquals("Current user not found in the database", exception.getMessage());
    }

    @Test
    void testGetBookingsByProperty_Success() {
        // Given
        when(bookingService.findBookingsByPropertyId(1L)).thenReturn(Arrays.asList(bookingDTO));

        // When
        ResponseEntity<List<BookingDTO>> response = bookingController.getBookingsByProperty(1L);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(bookingService).findBookingsByPropertyId(1L);
    }

    @Test
    void testCreateBooking_Success() {
        // Given
        BookingDTO inputBooking = new BookingDTO();
        inputBooking.setPropertyId(1L);

        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

        ResponseEntity<PropertyDTO> propertyResponse = ResponseEntity.ok(propertyDTO);
        when(propertyServiceClient.getProperty(1)).thenReturn(propertyResponse);

        when(bookingService.save(any(BookingDTO.class))).thenReturn(bookingDTO);

        // When
        ResponseEntity<BookingDTO> response = bookingController.createBooking(inputBooking);

        // Then
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNull(inputBooking.getId()); // Should be set to null
        assertEquals(1L, inputBooking.getUserId());
        assertEquals("testuser", inputBooking.getUserName());
        assertEquals("Test Property", inputBooking.getPropertyName());
        verify(bookingService).save(inputBooking);
    }

    @Test
    void testCreateBooking_PropertyNotFound() {
        // Given
        BookingDTO inputBooking = new BookingDTO();
        inputBooking.setPropertyId(1L);

        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);

        ResponseEntity<PropertyDTO> propertyResponse = ResponseEntity.notFound().build();
        when(propertyServiceClient.getProperty(1)).thenReturn(propertyResponse);

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> bookingController.createBooking(inputBooking));

        assertEquals("Property not found with ID: 1", exception.getMessage());
    }

    @Test
    void testUpdateBooking_Success_AsOwner() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(bookingService.findById(1)).thenReturn(bookingDTO);
        when(bookingService.save(any(BookingDTO.class))).thenReturn(bookingDTO);

        // When
        ResponseEntity<BookingDTO> response = bookingController.updateBooking(1, bookingDTO);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, bookingDTO.getId());
        verify(bookingService).save(bookingDTO);
    }

    @Test
    void testUpdateBooking_Forbidden() {
        // Given
        BookingDTO otherUserBooking = new BookingDTO();
        otherUserBooking.setUserId(999L); // Different user

        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(bookingService.findById(1)).thenReturn(otherUserBooking);

//        // When
//        ResponseEntity<BookingDTO> response = bookingController.updateBooking(1, bookingDTO);
//
//        // Then
//        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());


         // Then
         assertThrows(ForbiddenRoleException.class, () -> {
             // When
             bookingController.updateBooking(1, bookingDTO);
         });


        verify(bookingService, never()).save(any());
    }

    @Test
    void testUpdateBookingStatus_Success() {
        // Given
        when(bookingService.updateBookingStatus(1, "confirmed")).thenReturn(bookingDTO);

        // When
        ResponseEntity<BookingDTO> response = bookingController.updateBookingStatus(1, "confirmed");

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(bookingService).updateBookingStatus(1, "confirmed");
    }

    @Test
    void testUpdatePaymentDetails_Success() {
        // Given
        when(bookingService.updatePaymentDetails(1, "pay_123", "completed")).thenReturn(bookingDTO);

        // When
        ResponseEntity<BookingDTO> response = bookingController.updatePaymentDetails(1, "pay_123", "completed");

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(bookingService).updatePaymentDetails(1, "pay_123", "completed");
    }

    @Test
    void testCancelBooking_Success() {
        // Given
        Map<String, String> reason = new HashMap<>();
        reason.put("reason", "Change of plans");

        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(bookingService.findById(1)).thenReturn(bookingDTO);
        when(bookingService.cancelBooking(1, "Change of plans")).thenReturn(bookingDTO);

        // When
        ResponseEntity<BookingDTO> response = bookingController.cancelBooking(1, reason);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(bookingService).cancelBooking(1, "Change of plans");
    }

    @Test
    void testCancelBooking_WithoutReason() {
        // Given
        ResponseEntity<UserDTO> userResponse = ResponseEntity.ok(userDTO);
        when(userServiceClient.getUserByUsername("testuser")).thenReturn(userResponse);
        when(bookingService.findById(1)).thenReturn(bookingDTO);
        when(bookingService.cancelBooking(1, "Cancelled by user")).thenReturn(bookingDTO);

        // When
        ResponseEntity<BookingDTO> response = bookingController.cancelBooking(1, null);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(bookingService).cancelBooking(1, "Cancelled by user");
    }

    @Test
    void testDeleteBooking_Success() {
        // Given
        when(bookingService.findById(1)).thenReturn(bookingDTO);

        // When
        ResponseEntity<String> response = bookingController.deleteBooking(1);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Booking deleted successfully", response.getBody());
        verify(bookingService).deleteById(1);
    }
}