package com.propease.payment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Payment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Payment2Application.class, args);
	}

}
