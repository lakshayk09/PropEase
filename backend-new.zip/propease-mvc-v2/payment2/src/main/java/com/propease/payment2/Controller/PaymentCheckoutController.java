package com.propease.payment2.Controller;

import com.propease.payment2.Service.StripeService;
import com.propease.payment2.dto.ProductRequest;
import com.propease.payment2.dto.StripeResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/payment")
@Slf4j
public class PaymentCheckoutController {

    private final StripeService stripeService;

    @Autowired
    public PaymentCheckoutController(StripeService stripeService){
        this.stripeService = stripeService;
    }

    @PostMapping("/checkout")
    public ResponseEntity<StripeResponse> checkoutProducts(@RequestBody ProductRequest productRequest) {

        log.info("Stripe payment request received");

        StripeResponse stripeResponse = stripeService.checkoutProducts(productRequest);

        log.info("Payment response generated successfully with session id - {}", stripeResponse.getSessionId());

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(stripeResponse);
    }


}
