package com.propease.property.Service;

import com.propease.property.Entity.Property;
import com.propease.property.Repository.PropertyRepo;
import com.propease.property.dto.PropertyDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;



@ExtendWith(MockitoExtension.class)
class PropertyServiceImplTest {

    @Mock
    private PropertyRepo propertyRepo;

    @Mock
    private PropertyUtil propertyUtil;

    @InjectMocks
    private PropertyServiceImpl propertyService;

    private Property testProperty;
    private PropertyDTO testPropertyDTO;

    @BeforeEach
    void setUp() {
        testProperty = new Property();
        testProperty.setId(1);
        testProperty.setName("Test Property");
        testProperty.setAddedBy(1L);

        testPropertyDTO = new PropertyDTO();
        testPropertyDTO.setId(1);
        testPropertyDTO.setName("Test Property");
        testPropertyDTO.setAddedBy(1L);
        testPropertyDTO.setPrice(1000);
    }

    @Test
    void findAll_Success() {
        // Arrange
        List<Property> properties = Arrays.asList(testProperty);
        List<PropertyDTO> propertyDTOs = Arrays.asList(testPropertyDTO);

        when(propertyRepo.findAll()).thenReturn(properties);
        when(propertyUtil.mapEntityToDTOList(properties)).thenReturn(propertyDTOs);

        // Act
        List<PropertyDTO> result = propertyService.findAll();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(testPropertyDTO, result.get(0));

        verify(propertyRepo).findAll();
        verify(propertyUtil).mapEntityToDTOList(properties);
    }

    @Test
    void findById_Success() {
        // Arrange
        when(propertyRepo.findById(1)).thenReturn(Optional.of(testProperty));
        when(propertyUtil.mapEntityToDTO(testProperty)).thenReturn(testPropertyDTO);

        // Act
        PropertyDTO result = propertyService.findById(1);

        // Assert
        assertNotNull(result);
        assertEquals(testPropertyDTO, result);
        verify(propertyRepo).findById(1);
        verify(propertyUtil).mapEntityToDTO(testProperty);
    }

    @Test
    void findById_NotFound_ThrowsException() {
        // Arrange
        when(propertyRepo.findById(1)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> propertyService.findById(1)
        );

        assertEquals("Did not find property id - 1", exception.getMessage());
        verify(propertyRepo).findById(1);
        verifyNoInteractions(propertyUtil);
    }

    @Test
    void getPropertiesByUserId_Success() {
        // Arrange
        List<Property> properties = Arrays.asList(testProperty);
        List<PropertyDTO> propertyDTOs = Arrays.asList(testPropertyDTO);

        when(propertyRepo.findByAddedBy(1L)).thenReturn(properties);
        when(propertyUtil.mapEntityToDTOList(properties)).thenReturn(propertyDTOs);

        // Act
        List<PropertyDTO> result = propertyService.getPropertiesByUserId(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(testPropertyDTO, result.get(0));
        verify(propertyRepo).findByAddedBy(1L);
        verify(propertyUtil).mapEntityToDTOList(properties);
    }

    @Test
    void getPropertiesByUserId_EmptyList() {
        // Arrange
        List<Property> emptyProperties = Arrays.asList();
        List<PropertyDTO> emptyPropertyDTOs = Arrays.asList();

        when(propertyRepo.findByAddedBy(1L)).thenReturn(emptyProperties);
        when(propertyUtil.mapEntityToDTOList(emptyProperties)).thenReturn(emptyPropertyDTOs);

        // Act
        List<PropertyDTO> result = propertyService.getPropertiesByUserId(1L);

        // Assert
        assertNotNull(result);
        assertEquals(0, result.size());
        verify(propertyRepo).findByAddedBy(1L);
        verify(propertyUtil).mapEntityToDTOList(emptyProperties);
    }

    @Test
    void save_Success() {
        // Arrange
        when(propertyUtil.mapDTOToEntity(testPropertyDTO)).thenReturn(testProperty);
        when(propertyRepo.save(testProperty)).thenReturn(testProperty);
        when(propertyUtil.mapEntityToDTO(testProperty)).thenReturn(testPropertyDTO);

        // Act
        PropertyDTO result = propertyService.save(testPropertyDTO);

        // Assert
        assertNotNull(result);
        assertEquals(testPropertyDTO, result);
        verify(propertyUtil).mapDTOToEntity(testPropertyDTO);
        verify(propertyRepo).save(testProperty);
        verify(propertyUtil).mapEntityToDTO(testProperty);
    }

    @Test
    void save_NewProperty_Success() {
        // Arrange
        PropertyDTO newPropertyDTO = new PropertyDTO();
        newPropertyDTO.setName("New Property");
        newPropertyDTO.setAddedBy(2L);

        Property newProperty = new Property();
        newProperty.setName("New Property");
        newProperty.setAddedBy(2L);

        Property savedProperty = new Property();
        savedProperty.setId(2);
        savedProperty.setName("New Property");
        savedProperty.setAddedBy(2L);

        PropertyDTO savedPropertyDTO = new PropertyDTO();
        savedPropertyDTO.setId(2);
        savedPropertyDTO.setName("New Property");
        savedPropertyDTO.setAddedBy(2L);

        when(propertyUtil.mapDTOToEntity(newPropertyDTO)).thenReturn(newProperty);
        when(propertyRepo.save(newProperty)).thenReturn(savedProperty);
        when(propertyUtil.mapEntityToDTO(savedProperty)).thenReturn(savedPropertyDTO);

        // Act
        PropertyDTO result = propertyService.save(newPropertyDTO);

        // Assert
        assertNotNull(result);
        assertEquals(savedPropertyDTO, result);
        assertEquals(2L, result.getId().longValue());

        verify(propertyUtil).mapDTOToEntity(newPropertyDTO);
        verify(propertyRepo).save(newProperty);
        verify(propertyUtil).mapEntityToDTO(savedProperty);
    }

    @Test
    void deleteById_Success() {
        // Act
        propertyService.deleteById(1);

        // Assert
        verify(propertyRepo).deleteById(1);
    }

    @Test
    void deleteById_NonExistentId() {
        // Arrange
        doNothing().when(propertyRepo).deleteById(999);

        // Act
        propertyService.deleteById(999);

        // Assert
        verify(propertyRepo).deleteById(999);
    }

    @Test
    void findAll_MultipleProperties() {
        // Arrange
        Property property2 = new Property();
        property2.setId(2);
        property2.setName("Second Property");
        property2.setAddedBy(2L);

        PropertyDTO propertyDTO2 = new PropertyDTO();
        propertyDTO2.setId(2);
        propertyDTO2.setName("Second Property");
        propertyDTO2.setAddedBy(2L);

        List<Property> properties = Arrays.asList(testProperty, property2);
        List<PropertyDTO> propertyDTOs = Arrays.asList(testPropertyDTO, propertyDTO2);

        when(propertyRepo.findAll()).thenReturn(properties);
        when(propertyUtil.mapEntityToDTOList(properties)).thenReturn(propertyDTOs);

        // Act
        List<PropertyDTO> result = propertyService.findAll();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(testPropertyDTO, result.get(0));
        assertEquals(propertyDTO2, result.get(1));
        verify(propertyRepo).findAll();
        verify(propertyUtil).mapEntityToDTOList(properties);
    }
}