package com.propease.property.Service;



import com.propease.property.Entity.Property;
import com.propease.property.Exception.PropertyNotFoundException;
import com.propease.property.dto.PropertyDTO;
import com.propease.property.Repository.PropertyRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class PropertyServiceImpl implements PropertyService {

    private final PropertyRepo propertyRepo;
    private final PropertyUtil propertyUtil;

    @Autowired
    public PropertyServiceImpl(PropertyRepo thePropertyRepo, PropertyUtil propertyUtil) {
        this.propertyRepo = thePropertyRepo;
        this.propertyUtil = propertyUtil;
    }

    @Override
    public List<PropertyDTO> findAll() {
        log.info("Retrieving all properties");
        List<Property> properties = propertyRepo.findAll();
        return propertyUtil.mapEntityToDTOList(properties);
    }

    @Override
    public PropertyDTO findById(int theId) {
        Optional<Property> result = propertyRepo.findById(theId);

        Property property = result.orElseThrow(() -> {
            log.warn("Could not find property with id - {}", theId);
            return new PropertyNotFoundException("Did not find property id - " + theId);
        });

        return propertyUtil.mapEntityToDTO(property);
    }

    @Override
    public List<PropertyDTO> getPropertiesByUserId(Long ownerId) {
        List<Property> properties = propertyRepo.findByAddedBy(ownerId);

        log.info("Properties of the owner retrieved successfully");
        return propertyUtil.mapEntityToDTOList(properties);
    }

    @Override
    public PropertyDTO save(PropertyDTO propertyDTO) {

        Property property = propertyUtil.mapDTOToEntity(propertyDTO);
        Property savedProperty = propertyRepo.save(property);

        log.info("Property added successfully");
        return propertyUtil.mapEntityToDTO(savedProperty);
    }

    @Override
    public void deleteById(int theId) {
        propertyRepo.deleteById(theId);
        log.info("Property deleted with id - {}", theId);

    }
}

