package com.propease.property.Entity;


import jakarta.persistence.*;
import java.util.Set;

@Entity
@Table(name = "property")
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private String address;

    @Column(name = "image_url")
    private String imageUrl;

    @Enumerated(EnumType.STRING)
    private PropertyStatus status; // Enum for 'for_sale', 'for_rent'

    @Enumerated(EnumType.STRING)
    private PropertyType type; // Enum for 'apartment', 'pg', 'house'

    private String city;

    private String state;

    @Column(name = "contact_number")
    private String contactNumber;

//    @ManyToOne
    @Column(name = "added_by")
    private Long addedBy;

    private Integer price;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    private Integer rooms;

    // Many-to-many relationship with Feature through PropertyFeature
    @ManyToMany
    @JoinTable(
            name = "property_feature",
            joinColumns = @JoinColumn(name = "property_id"),
            inverseJoinColumns = @JoinColumn(name = "feature_id")
    )
    private Set<Feature> features;


    public Property() {}

    public Property(String name, String imageUrl, String address, PropertyStatus status, PropertyType type, String city, String state,
                    String contactNumber, Long addedBy, Integer price, Integer rooms, Set<Feature> features) {
        this.name = name;
        this.address = address;
        this.status = status;
        this.type = type;
        this.city = city;
        this.state = state;
        this.contactNumber = contactNumber;
        this.addedBy = addedBy;
        this.price = price;
        this.rooms = rooms;
        this.features = features;
        this.imageUrl = imageUrl;
    }

    // Getters and Setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public PropertyStatus getStatus() {
        return status;
    }

    public void setStatus(PropertyStatus status) {
        this.status = status;
    }

    public PropertyType getType() {
        return type;
    }

    public void setType(PropertyType type) {
        this.type = type;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public Long getAddedBy() {
        return addedBy;
    }

    public void setAddedBy(Long addedBy) {
        this.addedBy = addedBy;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getRooms() {
        return rooms;
    }

    public void setRooms(Integer rooms) {
        this.rooms = rooms;
    }

    public Set<Feature> getFeatures() {
        return features;
    }

    public void setFeatures(Set<Feature> features) {
        this.features = features;
    }
}

