package com.propease.property.Repository;


import com.propease.property.Entity.Property;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PropertyRepo extends JpaRepository<Property, Integer> {
    // implicit
//    List<Property> findByAddedBy(User user);

    // or explicit (for just Id)
    List<Property> findByAddedBy(Long userId);



}

