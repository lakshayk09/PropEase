package com.propease.property.Client;

import com.propease.property.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "${user.service.url:http://localhost:8081}")
public interface UserServiceClient {

    @GetMapping("/api/users/{userId}")
    ResponseEntity<UserDTO> getUserById(@PathVariable("userId") Long userId);

    @GetMapping("/api/users/username/{username}")
    ResponseEntity<UserDTO> getUserByUsername(@PathVariable("username") String username);
}