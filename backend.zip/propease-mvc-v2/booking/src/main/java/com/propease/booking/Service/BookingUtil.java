package com.propease.booking.Service;

import com.propease.booking.Client.PropertyServiceClient;
import com.propease.booking.Client.UserServiceClient;
import com.propease.booking.Entity.Booking;
import com.propease.booking.dto.BookingDTO;
import com.propease.booking.dto.PropertyDTO;
import com.propease.booking.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class BookingUtil {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final UserServiceClient userServiceClient;
    private final PropertyServiceClient propertyServiceClient;

    @Autowired
    public BookingUtil(UserServiceClient userServiceClient, PropertyServiceClient propertyServiceClient) {
        this.userServiceClient = userServiceClient;
        this.propertyServiceClient = propertyServiceClient;
    }

    public BookingDTO mapEntityToDTO(Booking booking) {
        BookingDTO dto = new BookingDTO();

        dto.setId(booking.getId());
        dto.setPropertyId(booking.getProperty());
        dto.setUserId(booking.getUser());

        // Fetch property details using Feign client
        try {
            ResponseEntity<PropertyDTO> propertyResponse = propertyServiceClient.getProperty(booking.getProperty().intValue());
            if (propertyResponse.getStatusCode().is2xxSuccessful() && propertyResponse.getBody() != null) {
                dto.setPropertyName(propertyResponse.getBody().getName());
            } else {
                dto.setPropertyName("Property not found");
            }
        } catch (Exception e) {
            dto.setPropertyName("Property service unavailable");
        }

        // Fetch user details using Feign client
        try {
            ResponseEntity<UserDTO> userResponse = userServiceClient.getUserById(booking.getUser());
            if (userResponse.getStatusCode().is2xxSuccessful() && userResponse.getBody() != null) {
                dto.setUserName(userResponse.getBody().getUserName());
            } else {
                dto.setUserName("User not found");
            }
        } catch (Exception e) {
            dto.setUserName("User service unavailable");
        }

        // Format dates as strings
        dto.setBookingDate(booking.getBookingDate().format(DATE_FORMATTER));
        dto.setStartDate(booking.getStartDate().format(DATE_FORMATTER));
        dto.setEndDate(booking.getEndDate().format(DATE_FORMATTER));

        dto.setBookingAmount(booking.getBookingAmount());
        dto.setBookingStatus(booking.getBookingStatus().toString());
        dto.setPaymentId(booking.getPaymentId());
        dto.setPaymentStatus(booking.getPaymentStatus());
        dto.setSpecialRequests(booking.getSpecialRequests());
        dto.setGuestCount(booking.getGuestCount());

        return dto;
    }

    public List<BookingDTO> mapEntityToDTOList(List<Booking> bookings) {
        return bookings.stream()
                .map(this::mapEntityToDTO)
                .collect(Collectors.toList());
    }
}