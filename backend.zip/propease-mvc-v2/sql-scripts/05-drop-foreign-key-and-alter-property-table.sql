-- Property table update
ALTER TABLE property 
DROP FOREIGN KEY property_ibfk_1;

ALTER TABLE property 
MODIFY COLUMN added_by BIGINT NOT NULL;

-- Index for better performance
CREATE INDEX idx_property_added_by ON property(added_by);
