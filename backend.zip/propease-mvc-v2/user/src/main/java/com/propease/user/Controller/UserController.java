package com.propease.user.Controller;


import com.propease.user.Entity.User;
import com.propease.user.Service.UserService;
import com.propease.user.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<UserDTO> getUserById(@PathVariable Long userId) {
        User user = userService.findUserById(userId);
        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        UserDTO userDTO = new UserDTO(
                user.getId(),
                user.getUserName(),
                user.getRole().getName()
        );

        return ResponseEntity.ok(userDTO);
    }

    @GetMapping("/username/{username}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<UserDTO> getUserByUsername(@PathVariable String username) {
        User user = userService.findUserByUserName(username);
        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        UserDTO userDTO = new UserDTO(
                user.getId(),
                user.getUserName(),
                user.getRole().getName()
        );

        return ResponseEntity.ok(userDTO);
    }

    @GetMapping("/loaduser/{username}")
    @PreAuthorize("permitAll()")
    public UserDetails loadUserByUsername(@PathVariable String username) {
        UserDetails user = userService.loadUserByUsername(username);

        return user;
    }
}
