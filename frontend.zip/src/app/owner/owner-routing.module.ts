import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OwnerLayoutComponent } from './owner-layout/owner-layout.component';
import { AddPropertyComponent } from './add-property/add-property.component';
import { ViewPropertiesComponent } from './view-properties/view-properties.component';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';

const routes: Routes = [
  {
    path: '',
    component: OwnerLayoutComponent,
    children: [
      { path: 'add-property', component: AddPropertyComponent },
      { path: 'view-properties', component: ViewPropertiesComponent },
      { path: 'view-bookings', component: ViewBookingsComponent  },
      { path: '', redirectTo: 'view-properties', pathMatch: 'full' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OwnerRoutingModule {}
