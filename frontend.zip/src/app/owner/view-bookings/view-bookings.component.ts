import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';


 interface Booking {
  id: number;
  propertyId: number;
  propertyName: string;
  userId: number;
  userName: string;
  bookingDate: string;
  startDate: string;
  endDate: string;
  bookingAmount: number;
  bookingStatus: string;
  paymentId?: string | null;
  paymentStatus?: string | null;
  specialRequests?: string;
  guestCount: number;
}


@Component({
  imports: [CommonModule],
  selector: 'app-view-bookings',
  templateUrl: './view-bookings.component.html',
  styleUrls: ['./view-bookings.component.scss']
})
export class ViewBookingsComponent {

  bookings: Booking[] = []

  currentPage: number = 1;
  itemsPerPage: number = 5;

  
  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadOwnerBookings();
  }
  
  loadOwnerBookings(): void {
    const token = sessionStorage.getItem('token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<Booking[]>(`${environment.apiBaseUrl}/api/bookings/owner`, { headers }).subscribe({
      next: (data) => {
        this.bookings = data.sort((a,b) => b.id - a.id);
      },
      error: (err) => {
        console.error('Failed to load owner bookings:', err);
      }
    });
  }


  get paginatedBookings(): Booking[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.bookings.slice(start, start + this.itemsPerPage);
  }

  get totalPages(): number {
    return Math.ceil(this.bookings.length / this.itemsPerPage);
  }

  changePage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }



}

