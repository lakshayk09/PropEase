import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-detail',
  imports: [],
  templateUrl: './booking-detail.component.html',
  styleUrl: './booking-detail.component.scss'
})
export class BookingDetailComponent {

}
