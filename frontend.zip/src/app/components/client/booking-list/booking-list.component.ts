import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-list',
  imports: [],
  templateUrl: './booking-list.component.html',
  styleUrl: './booking-list.component.scss'
})
export class BookingListComponent {

}
