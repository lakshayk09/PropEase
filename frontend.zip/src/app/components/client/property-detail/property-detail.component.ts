import { Component } from '@angular/core';

@Component({
  selector: 'app-property-detail',
  imports: [],
  templateUrl: './property-detail.component.html',
  styleUrl: './property-detail.component.scss'
})
export class PropertyDetailComponent {

}
