import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({ providedIn: 'root' })
export class BookingService {
  private baseUrl = 'http://localhost:8222/api/bookings';

  constructor(private http: HttpClient) {}

  getUserBookings() {
    return this.http.get(`${this.baseUrl}/user`);
  }

  getBookingById(id: number) {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  updateBooking(id: number, data: any) {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  cancelBooking(id: number) {
    return this.http.put(`${this.baseUrl}/${id}/cancel`, {});
  }

  createBooking(data: any) {
    return this.http.post(`${this.baseUrl}`, data);
  }
}
