// app.module.ts
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [
    // other imports...
    HttpClientModule
  ]
})
export class AppModule {}
