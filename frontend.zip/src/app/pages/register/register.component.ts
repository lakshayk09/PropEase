// register.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from 'src/app/shared/navbar/navbar.component';
import { UserService } from 'src/app/services/user.service';
import { Router, RouterModule } from '@angular/router';

@Component({
  imports: [FormsModule, CommonModule, NavbarComponent, RouterModule],
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  standalone: true
})
export class RegisterComponent {
  userName = '';
  password = '';
  roleName = '';

  constructor(private userService: UserService, private router: Router) {}

  onSubmit() {
    const payload = {
      userName: this.userName,
      password: this.password,
      roleName: this.roleName
    };

    this.userService.registerUser(payload).subscribe({
      next: (res) => {
        console.log('User registered successfully', res);
        alert("User Registered");
        this.router.navigate(["/login"]);
      },
      error: (err) => {
        console.error('Registration failed', err);
      }
    });
  }
}
