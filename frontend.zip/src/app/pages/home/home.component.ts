import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from 'src/app/shared/navbar/navbar.component';
import { FooterComponent } from 'src/app/shared/footer/footer.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, NavbarComponent, RouterModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  isLoggedIn = false;

  constructor(private router: Router) {
    // Check login status whenever this component is initialized
    this.checkLoginStatus();
  }

  // Function to check if user is logged in
  checkLoginStatus() {
    this.isLoggedIn = !!sessionStorage.getItem('authToken');
  }

  logout() {
    // Clear sessionStorage to log out
    sessionStorage.clear();
    // Check login status again after logging out
    this.checkLoginStatus();
    // Navigate to login page
    this.router.navigate(['/']);
  }

  goToClientHome() {
    this.router.navigate(['/client-portal-home']);
  }

  goToMerchantHome() {
    this.router.navigate(['/merchant-portal-home']);
  }

  browseMovies() {
    this.router.navigate(['/movies']);
  }
}
