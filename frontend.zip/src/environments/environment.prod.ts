export const environment = {
    production: true,
    apiBaseUrl: 'https://your-prod-url.com/api'
  };
  