package com.propease.auth2.Entity;

public enum Role {
    TENANT,
    OWNER,
    ADMIN
}
