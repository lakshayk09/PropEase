package com.propease.payment2.Controller;

import com.propease.payment2.Service.StripeService;
import com.propease.payment2.dto.ProductRequest;
import com.propease.payment2.dto.StripeResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentCheckoutControllerTest {

    @Mock
    private StripeService stripeService;

    @InjectMocks
    private PaymentCheckoutController paymentCheckoutController;

    private ProductRequest productRequest;
    private StripeResponse stripeResponse;

    @BeforeEach
    void setUp() {
        productRequest = new ProductRequest();
        productRequest.setAmount(10000L);
        productRequest.setCurrency("USD");
        productRequest.setName("Test Product");
        productRequest.setQuantity(1L);

        stripeResponse = new StripeResponse();
        stripeResponse.setStatus("SUCCESS");
        stripeResponse.setMessage("Payment session created successfully");
        stripeResponse.setSessionId("cs_test_session_id");
        stripeResponse.setSessionUrl("https://checkout.stripe.com/pay/cs_test_session_id");
    }

    @Test
    void testCheckoutProducts_Success() {
        when(stripeService.checkoutProducts(productRequest)).thenReturn(stripeResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(productRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("SUCCESS", response.getBody().getStatus());
        assertEquals("Payment session created successfully", response.getBody().getMessage());
        assertEquals("cs_test_session_id", response.getBody().getSessionId());
        assertEquals("https://checkout.stripe.com/pay/cs_test_session_id", response.getBody().getSessionUrl());
        verify(stripeService).checkoutProducts(productRequest);
    }

    @Test
    void testCheckoutProducts_FailureResponse() {
        StripeResponse failureResponse = new StripeResponse();
        failureResponse.setStatus("FAILED");
        failureResponse.setMessage("Payment processing failed");
        failureResponse.setSessionId(null);
        failureResponse.setSessionUrl(null);

        when(stripeService.checkoutProducts(productRequest)).thenReturn(failureResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(productRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("FAILED", response.getBody().getStatus());
        assertEquals("Payment processing failed", response.getBody().getMessage());
        assertNull(response.getBody().getSessionId());
        assertNull(response.getBody().getSessionUrl());
        verify(stripeService).checkoutProducts(productRequest);
    }

    @Test
    void testCheckoutProducts_WithDifferentCurrency() {
        ProductRequest eurRequest = new ProductRequest();
        eurRequest.setAmount(8500L);
        eurRequest.setCurrency("EUR");
        eurRequest.setName("EUR Product");
        eurRequest.setQuantity(2L);

        StripeResponse eurResponse = new StripeResponse();
        eurResponse.setStatus("SUCCESS");
        eurResponse.setMessage("EUR payment session created");
        eurResponse.setSessionId("cs_eur_session_id");
        eurResponse.setSessionUrl("https://checkout.stripe.com/pay/cs_eur_session_id");

        when(stripeService.checkoutProducts(eurRequest)).thenReturn(eurResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(eurRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("SUCCESS", response.getBody().getStatus());
        assertEquals("cs_eur_session_id", response.getBody().getSessionId());
        verify(stripeService).checkoutProducts(eurRequest);
    }

    @Test
    void testCheckoutProducts_WithLargeAmount() {
        ProductRequest largeAmountRequest = new ProductRequest();
        largeAmountRequest.setAmount(999999L);
        largeAmountRequest.setCurrency("USD");
        largeAmountRequest.setName("High Value Product");
        largeAmountRequest.setQuantity(1L);

        when(stripeService.checkoutProducts(largeAmountRequest)).thenReturn(stripeResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(largeAmountRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("SUCCESS", response.getBody().getStatus());
        verify(stripeService).checkoutProducts(largeAmountRequest);
    }

    @Test
    void testCheckoutProducts_ServiceThrowsException() {
        when(stripeService.checkoutProducts(productRequest))
                .thenThrow(new RuntimeException("Stripe service unavailable"));

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> paymentCheckoutController.checkoutProducts(productRequest));

        assertEquals("Stripe service unavailable", exception.getMessage());
        verify(stripeService).checkoutProducts(productRequest);
    }

    @Test
    void testCheckoutProducts_WithNullAmount() {
        ProductRequest nullAmountRequest = new ProductRequest();
        nullAmountRequest.setAmount(null);
        nullAmountRequest.setCurrency("USD");
        nullAmountRequest.setName("Null Amount Product");
        nullAmountRequest.setQuantity(1L);

        StripeResponse errorResponse = new StripeResponse();
        errorResponse.setStatus("ERROR");
        errorResponse.setMessage("Amount cannot be null");

        when(stripeService.checkoutProducts(nullAmountRequest)).thenReturn(errorResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(nullAmountRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ERROR", response.getBody().getStatus());
        assertEquals("Amount cannot be null", response.getBody().getMessage());
    }

    @Test
    void testCheckoutProducts_WithZeroAmount() {
        ProductRequest zeroAmountRequest = new ProductRequest();
        zeroAmountRequest.setAmount(0L);
        zeroAmountRequest.setCurrency("USD");
        zeroAmountRequest.setName("Zero Amount Product");
        zeroAmountRequest.setQuantity(1L);

        StripeResponse errorResponse = new StripeResponse();
        errorResponse.setStatus("ERROR");
        errorResponse.setMessage("Amount must be greater than zero");

        when(stripeService.checkoutProducts(zeroAmountRequest)).thenReturn(errorResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(zeroAmountRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ERROR", response.getBody().getStatus());
        assertEquals("Amount must be greater than zero", response.getBody().getMessage());
    }

    @Test
    void testCheckoutProducts_WithEmptyProductName() {
        ProductRequest emptyNameRequest = new ProductRequest();
        emptyNameRequest.setAmount(5000L);
        emptyNameRequest.setCurrency("USD");
        emptyNameRequest.setName("");
        emptyNameRequest.setQuantity(1L);

        when(stripeService.checkoutProducts(emptyNameRequest)).thenReturn(stripeResponse);

        ResponseEntity<StripeResponse> response = paymentCheckoutController.checkoutProducts(emptyNameRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("SUCCESS", response.getBody().getStatus());
        verify(stripeService).checkoutProducts(emptyNameRequest);
    }
}
