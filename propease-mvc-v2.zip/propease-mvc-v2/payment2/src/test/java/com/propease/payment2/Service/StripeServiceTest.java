package com.propease.payment2.Service;

import com.propease.payment2.dto.ProductRequest;
import com.propease.payment2.dto.StripeResponse;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StripeServiceTest {

    @InjectMocks
    private StripeService stripeService;

    private ProductRequest productRequest;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(stripeService, "secretKey", "test_secret_key");

        productRequest = new ProductRequest();
        productRequest.setName("Test Product");
        productRequest.setAmount(100L);
        productRequest.setQuantity(1L);
        productRequest.setCurrency("USD");
    }

    @Test
    void checkoutProducts_Success() {
        Session mockSession = mock(Session.class);
        when(mockSession.getId()).thenReturn("session_123");
        when(mockSession.getUrl()).thenReturn("https://checkout.stripe.com/session_123");

        try (MockedStatic<Session> mockedSession = mockStatic(Session.class)) {
            // Fixed: Use any(SessionCreateParams.class) instead of anyMap()
            mockedSession.when(() -> Session.create(any(SessionCreateParams.class))).thenReturn(mockSession);

            StripeResponse response = stripeService.checkoutProducts(productRequest);

            assertNotNull(response);
            assertEquals("SUCCESS", response.getStatus());
            assertEquals("Payment session created", response.getMessage());
            assertEquals("session_123", response.getSessionId());
            assertEquals("https://checkout.stripe.com/session_123", response.getSessionUrl());

            mockedSession.verify(() -> Session.create(any(SessionCreateParams.class)));
        }
    }

    @Test
    void checkoutProducts_WithDefaultCurrency_Success() {
        productRequest.setCurrency(null);

        Session mockSession = mock(Session.class);
        when(mockSession.getId()).thenReturn("session_123");
        when(mockSession.getUrl()).thenReturn("https://checkout.stripe.com/session_123");

        try (MockedStatic<Session> mockedSession = mockStatic(Session.class)) {
            mockedSession.when(() -> Session.create(any(SessionCreateParams.class))).thenReturn(mockSession);

            StripeResponse response = stripeService.checkoutProducts(productRequest);

            assertNotNull(response);
            assertEquals("SUCCESS", response.getStatus());
            assertEquals("Payment session created", response.getMessage());
            assertEquals("session_123", response.getSessionId());
            assertEquals("https://checkout.stripe.com/session_123", response.getSessionUrl());
        }
    }

//    @Test
//    void checkoutProducts_StripeException_ReturnsSuccessWithNullValues() {
//        try (MockedStatic<Session> mockedSession = mockStatic(Session.class)) {
//            mockedSession.when(() -> Session.create(any(SessionCreateParams.class)))
//                    .thenThrow(new StripeException("Stripe error", "request_id", "code", 400) {});
//
//            StripeResponse response = stripeService.checkoutProducts(productRequest);
//
//            assertNotNull(response);
//            assertEquals("SUCCESS", response.getStatus());
//            assertEquals("Payment session created", response.getMessage());
//            assertNull(response.getSessionId());
//            assertNull(response.getSessionUrl());
//        }
//    }

    @Test
    void checkoutProducts_WithCustomCurrency_Success() {
        productRequest.setCurrency("EUR");

        Session mockSession = mock(Session.class);
        when(mockSession.getId()).thenReturn("session_456");
        when(mockSession.getUrl()).thenReturn("https://checkout.stripe.com/session_456");

        try (MockedStatic<Session> mockedSession = mockStatic(Session.class)) {
            mockedSession.when(() -> Session.create(any(SessionCreateParams.class))).thenReturn(mockSession);

            StripeResponse response = stripeService.checkoutProducts(productRequest);

            assertNotNull(response);
            assertEquals("SUCCESS", response.getStatus());
            assertEquals("session_456", response.getSessionId());
            assertEquals("https://checkout.stripe.com/session_456", response.getSessionUrl());
        }
    }

    @Test
    void checkoutProducts_LargeAmount_Success() {
        productRequest.setAmount(50000L);
        productRequest.setQuantity(2L);

        Session mockSession = mock(Session.class);
        when(mockSession.getId()).thenReturn("session_789");
        when(mockSession.getUrl()).thenReturn("https://checkout.stripe.com/session_789");

        try (MockedStatic<Session> mockedSession = mockStatic(Session.class)) {
            mockedSession.when(() -> Session.create(any(SessionCreateParams.class))).thenReturn(mockSession);

            StripeResponse response = stripeService.checkoutProducts(productRequest);

            assertNotNull(response);
            assertEquals("SUCCESS", response.getStatus());
            assertEquals("session_789", response.getSessionId());
        }
    }

    @Test
    void checkoutProducts_VerifyStripeApiKeySet() {
        Session mockSession = mock(Session.class);
        when(mockSession.getId()).thenReturn("session_123");
        when(mockSession.getUrl()).thenReturn("https://checkout.stripe.com/session_123");

        try (MockedStatic<Session> mockedSession = mockStatic(Session.class)) {
            mockedSession.when(() -> Session.create(any(SessionCreateParams.class))).thenReturn(mockSession);

            stripeService.checkoutProducts(productRequest);

            assertEquals("test_secret_key", Stripe.apiKey);
        }
    }
}