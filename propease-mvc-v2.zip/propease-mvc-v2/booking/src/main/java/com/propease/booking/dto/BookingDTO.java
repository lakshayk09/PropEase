package com.propease.booking.dto;


public class BookingDTO {
    private Integer id;
    private Long propertyId;
    private String propertyName;    // For convenience in UI
    private Long userId;
    private String userName;        // For convenience in UI
    private String bookingDate;
    private String startDate;
    private String endDate;
    private Double bookingAmount;
    private String bookingStatus;
    private String paymentId;
    private String paymentStatus;
    private String specialRequests;
    private Integer guestCount;

    // No-args constructor
    public BookingDTO() {
    }

    // All args constructor
    public BookingDTO(Integer id, Long propertyId, String propertyName, Long userId, String userName,
                      String bookingDate, String startDate, String endDate, Double bookingAmount,
                      String bookingStatus, String paymentId, String paymentStatus,
                      String specialRequests, Integer guestCount) {
        this.id = id;
        this.propertyId = propertyId;
        this.propertyName = propertyName;
        this.userId = userId;
        this.userName = userName;
        this.bookingDate = bookingDate;
        this.startDate = startDate;
        this.endDate = endDate;
        this.bookingAmount = bookingAmount;
        this.bookingStatus = bookingStatus;
        this.paymentId = paymentId;
        this.paymentStatus = paymentStatus;
        this.specialRequests = specialRequests;
        this.guestCount = guestCount;
    }

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Long propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Double getBookingAmount() {
        return bookingAmount;
    }

    public void setBookingAmount(Double bookingAmount) {
        this.bookingAmount = bookingAmount;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public Integer getGuestCount() {
        return guestCount;
    }

    public void setGuestCount(Integer guestCount) {
        this.guestCount = guestCount;
    }
}
