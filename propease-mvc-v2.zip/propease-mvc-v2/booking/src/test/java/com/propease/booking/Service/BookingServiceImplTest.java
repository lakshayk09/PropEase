package com.propease.booking.Service;

import com.propease.booking.Client.PropertyServiceClient;
import com.propease.booking.Client.UserServiceClient;
import com.propease.booking.Entity.Booking;
import com.propease.booking.Entity.BookingStatus;
import com.propease.booking.Repository.BookingRepo;
import com.propease.booking.dto.BookingDTO;
import com.propease.booking.dto.PropertyDTO;
import com.propease.booking.dto.UserDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceImplTest {

    @Mock
    private BookingRepo bookingRepo;

    @Mock
    private PropertyServiceClient propertyServiceClient;

    @Mock
    private UserServiceClient userServiceClient;

    @Mock
    private BookingUtil bookingUtil;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private Booking testBooking;
    private BookingDTO testBookingDTO;
    private UserDTO testUser;
    private PropertyDTO testProperty;

    @BeforeEach
    void setUp() {
        testBooking = new Booking();
        testBooking.setId(1);
        testBooking.setProperty(1L);
        testBooking.setUser(1L);
        testBooking.setBookingStatus(BookingStatus.confirmed);

        testBookingDTO = new BookingDTO();
        testBookingDTO.setId(1);
        testBookingDTO.setPropertyId(1L);
        testBookingDTO.setStartDate("2025-12-01");
        testBookingDTO.setEndDate("2025-12-05");
        testBookingDTO.setBookingAmount(500.0);
        testBookingDTO.setGuestCount(2);

        testUser = new UserDTO();
        testUser.setId(1L);
        testUser.setUserName("testuser");

        testProperty = new PropertyDTO();
        testProperty.setId(1);
        testProperty.setName("Test Property");
    }

    @Test
    void findAll_Success() {
        // Arrange
        List<Booking> bookings = Arrays.asList(testBooking);
        List<BookingDTO> bookingDTOs = Arrays.asList(testBookingDTO);

        when(bookingRepo.findAll()).thenReturn(bookings);
        when(bookingUtil.mapEntityToDTOList(bookings)).thenReturn(bookingDTOs);

        // Act
        List<BookingDTO> result = bookingService.findAll();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(bookingRepo).findAll();
        verify(bookingUtil).mapEntityToDTOList(bookings);
    }

    @Test
    void findById_Success() {
        // Arrange
        when(bookingRepo.findById(1)).thenReturn(Optional.of(testBooking));
        when(bookingUtil.mapEntityToDTO(testBooking)).thenReturn(testBookingDTO);

        // Act
        BookingDTO result = bookingService.findById(1);

        // Assert
        assertNotNull(result);
        assertEquals(testBookingDTO, result);
        verify(bookingRepo).findById(1);
        verify(bookingUtil).mapEntityToDTO(testBooking);
    }

    @Test
    void findById_NotFound_ThrowsException() {
        // Arrange
        when(bookingRepo.findById(1)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> bookingService.findById(1)
        );

        assertEquals("Did not find booking with id - 1", exception.getMessage());
        verify(bookingRepo).findById(1);
        verifyNoInteractions(bookingUtil);
    }

    @Test
    void save_NewBooking_Success() {
        // Arrange
        testBookingDTO.setId(null);
        testBookingDTO.setBookingStatus(null);

        try (MockedStatic<SecurityContextHolder> mockedSecurityContext = mockStatic(SecurityContextHolder.class)) {
            mockedSecurityContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("testuser");

            when(userServiceClient.getUserByUsername("testuser"))
                    .thenReturn(ResponseEntity.ok(testUser));
            when(propertyServiceClient.getProperty(1))
                    .thenReturn(ResponseEntity.ok(testProperty));
            when(bookingRepo.save(any(Booking.class))).thenReturn(testBooking);
            when(bookingUtil.mapEntityToDTO(testBooking)).thenReturn(testBookingDTO);

            // Act
            BookingDTO result = bookingService.save(testBookingDTO);

            // Assert
            assertNotNull(result);
            verify(userServiceClient).getUserByUsername("testuser");
            verify(propertyServiceClient).getProperty(1);
            verify(bookingRepo).save(any(Booking.class));
            verify(bookingUtil).mapEntityToDTO(testBooking);
        }
    }

    @Test
    void save_CancelledBooking_ThrowsException() {
        // Arrange
        testBookingDTO.setBookingStatus("cancelled");

        try (MockedStatic<SecurityContextHolder> mockedSecurityContext = mockStatic(SecurityContextHolder.class)) {
            mockedSecurityContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("testuser");

            when(userServiceClient.getUserByUsername("testuser"))
                    .thenReturn(ResponseEntity.ok(testUser));

            // Act & Assert
            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> bookingService.save(testBookingDTO)
            );

            assertEquals("Booking has already been cancelled", exception.getMessage());
        }
    }

    @Test
    void save_PastStartDate_ThrowsException() {
        // Arrange
        testBookingDTO.setId(null);
        testBookingDTO.setStartDate("2020-01-01"); // Past date

        try (MockedStatic<SecurityContextHolder> mockedSecurityContext = mockStatic(SecurityContextHolder.class)) {
            mockedSecurityContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("testuser");

            when(userServiceClient.getUserByUsername("testuser"))
                    .thenReturn(ResponseEntity.ok(testUser));
            when(propertyServiceClient.getProperty(1))
                    .thenReturn(ResponseEntity.ok(testProperty));

            // Act & Assert
            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> bookingService.save(testBookingDTO)
            );

            assertEquals("Booking start date cannot be in the past.", exception.getMessage());
        }
    }

    @Test
    void save_UserNotFound_ThrowsException() {
        // Arrange
        try (MockedStatic<SecurityContextHolder> mockedSecurityContext = mockStatic(SecurityContextHolder.class)) {
            mockedSecurityContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("testuser");

            when(userServiceClient.getUserByUsername("testuser"))
                    .thenReturn(ResponseEntity.status(HttpStatus.NOT_FOUND).build());

            // Act & Assert
            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> bookingService.save(testBookingDTO)
            );

            assertEquals("Current user not found while creating booking", exception.getMessage());
        }
    }

    @Test
    void save_PropertyNotFound_ThrowsException() {
        // Arrange
        try (MockedStatic<SecurityContextHolder> mockedSecurityContext = mockStatic(SecurityContextHolder.class)) {
            mockedSecurityContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("testuser");

            when(userServiceClient.getUserByUsername("testuser"))
                    .thenReturn(ResponseEntity.ok(testUser));
            when(propertyServiceClient.getProperty(1))
                    .thenReturn(ResponseEntity.status(HttpStatus.NOT_FOUND).build());

            // Act & Assert
            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> bookingService.save(testBookingDTO)
            );

            assertEquals("Property not found with ID: 1", exception.getMessage());
        }
    }

    @Test
    void deleteById_Success() {
        // Act
        bookingService.deleteById(1);

        // Assert
        verify(bookingRepo).deleteById(1);
    }

    @Test
    void findBookingsByUserId_Success() {
        // Arrange
        List<Booking> bookings = Arrays.asList(testBooking);
        List<BookingDTO> bookingDTOs = Arrays.asList(testBookingDTO);

        when(bookingRepo.findByUserId(1L)).thenReturn(bookings);
        when(bookingUtil.mapEntityToDTOList(bookings)).thenReturn(bookingDTOs);

        // Act
        List<BookingDTO> result = bookingService.findBookingsByUserId(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(bookingRepo).findByUserId(1L);
        verify(bookingUtil).mapEntityToDTOList(bookings);
    }

    @Test
    void findBookingsByPropertyId_Success() {
        // Arrange
        List<Booking> bookings = Arrays.asList(testBooking);
        List<BookingDTO> bookingDTOs = Arrays.asList(testBookingDTO);

        when(bookingRepo.findByPropertyId(1L)).thenReturn(bookings);
        when(bookingUtil.mapEntityToDTOList(bookings)).thenReturn(bookingDTOs);

        // Act
        List<BookingDTO> result = bookingService.findBookingsByPropertyId(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(bookingRepo).findByPropertyId(1L);
        verify(bookingUtil).mapEntityToDTOList(bookings);
    }

    @Test
    void updateBookingStatus_Success() {
        // Arrange
        when(bookingRepo.findById(1)).thenReturn(Optional.of(testBooking));
        when(bookingRepo.save(testBooking)).thenReturn(testBooking);
        when(bookingUtil.mapEntityToDTO(testBooking)).thenReturn(testBookingDTO);

        // Act
        BookingDTO result = bookingService.updateBookingStatus(1, "confirmed");

        // Assert
        assertNotNull(result);
        assertEquals(BookingStatus.confirmed, testBooking.getBookingStatus());
        verify(bookingRepo).findById(1);
        verify(bookingRepo).save(testBooking);
        verify(bookingUtil).mapEntityToDTO(testBooking);
    }

    @Test
    void updateBookingStatus_BookingNotFound_ThrowsException() {
        // Arrange
        when(bookingRepo.findById(1)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> bookingService.updateBookingStatus(1, "confirmed")
        );

        assertEquals("Booking not found with id: 1", exception.getMessage());
        verify(bookingRepo).findById(1);
        verify(bookingRepo, never()).save(any());
    }

    @Test
    void updatePaymentDetails_Success() {
        // Arrange
        when(bookingRepo.findById(1)).thenReturn(Optional.of(testBooking));
        when(bookingRepo.save(testBooking)).thenReturn(testBooking);
        when(bookingUtil.mapEntityToDTO(testBooking)).thenReturn(testBookingDTO);

        // Act
        BookingDTO result = bookingService.updatePaymentDetails(1, "payment123", "COMPLETED");

        // Assert
        assertNotNull(result);
        assertEquals("payment123", testBooking.getPaymentId());
        assertEquals("COMPLETED", testBooking.getPaymentStatus());
        assertEquals(BookingStatus.confirmed, testBooking.getBookingStatus());
        verify(bookingRepo).findById(1);
        verify(bookingRepo).save(testBooking);
    }

    @Test
    void cancelBooking_Success() {
        // Arrange
        testBooking.setSpecialRequests("Existing request");
        when(bookingRepo.findById(1)).thenReturn(Optional.of(testBooking));
        when(bookingRepo.save(testBooking)).thenReturn(testBooking);
        when(bookingUtil.mapEntityToDTO(testBooking)).thenReturn(testBookingDTO);

        // Act
        BookingDTO result = bookingService.cancelBooking(1, "Changed plans");

        // Assert
        assertNotNull(result);
        assertEquals(BookingStatus.cancelled, testBooking.getBookingStatus());
        assertTrue(testBooking.getSpecialRequests().contains("Cancellation reason: Changed plans"));
        verify(bookingRepo).findById(1);
        verify(bookingRepo).save(testBooking);
    }
}