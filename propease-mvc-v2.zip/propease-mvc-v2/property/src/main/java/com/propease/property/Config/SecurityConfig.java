package com.propease.property.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.GET, "/api/properties").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/properties/{propertyId}").hasAnyRole("TENANT", "OWNER", "ADMIN")                        .requestMatchers(HttpMethod.GET, "/api/properties/user").hasRole("OWNER")
                        // More specific patterns must come before less specific ones
                        .requestMatchers(HttpMethod.GET, "/api/properties/user").permitAll()

                        .requestMatchers(HttpMethod.GET, "/api/properties/user/{ownerId}").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/properties").hasRole("OWNER")
                        .requestMatchers(HttpMethod.PUT, "/api/properties").hasRole("OWNER")
                        .requestMatchers(HttpMethod.PATCH, "/api/properties/{propertyId}").hasRole("OWNER")
                        .requestMatchers(HttpMethod.DELETE, "/api/properties/{propertyId}").hasAnyRole("OWNER", "ADMIN")
                        .anyRequest().authenticated()
                )
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwt -> jwt
                                .jwtAuthenticationConverter(jwtAuthenticationConverter())
                        )
                );

        return http.build();
    }

    @Bean
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter converter = new JwtGrantedAuthoritiesConverter();
        converter.setAuthoritiesClaimName("role");     // Your token uses "role"
        converter.setAuthorityPrefix("");              // Already prefixed with "ROLE_" in token

        JwtAuthenticationConverter jwtConverter = new JwtAuthenticationConverter();
        jwtConverter.setJwtGrantedAuthoritiesConverter(converter);
        return jwtConverter;
    }

    @Bean
    public JwtDecoder jwtDecoder() {
        String secret = "yoursecretkey012345678901234567890123456789"; // Must match your auth service
        SecretKey key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
        return NimbusJwtDecoder.withSecretKey(key).build();
    }
}

