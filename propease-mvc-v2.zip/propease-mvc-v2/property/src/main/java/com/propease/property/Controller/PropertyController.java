package com.propease.property.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.propease.property.dto.PropertyDTO;
import com.propease.property.Service.PropertyService;
import com.propease.property.Client.UserServiceClient;
import com.propease.property.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class PropertyController {

    private final PropertyService propertyService;
    private final ObjectMapper objectMapper;
    private final UserServiceClient userServiceClient;

    @Autowired
    public PropertyController(PropertyService propertyService, ObjectMapper objectMapper,
                              UserServiceClient userServiceClient) {
        this.propertyService = propertyService;
        this.objectMapper = objectMapper;
        this.userServiceClient = userServiceClient;
    }

    @GetMapping("/properties")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<PropertyDTO>> findAll() {
        List<PropertyDTO> propertyDTOs = propertyService.findAll();
        return new ResponseEntity<>(propertyDTOs, HttpStatus.OK);
    }

    @GetMapping("/properties/{propertyId}")
    @PreAuthorize("hasAnyRole('TENANT', 'OWNER')")
    public ResponseEntity<PropertyDTO> getProperty(@PathVariable int propertyId) {
        PropertyDTO propertyDTO = propertyService.findById(propertyId);
        return new ResponseEntity<>(propertyDTO, HttpStatus.OK);
    }

    @GetMapping("/properties/user")
//    @PreAuthorize("hasRole('OWNER')")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<PropertyDTO>> getPropertiesAddedByOwner() {
        // Get username of the currently authenticated user
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        // Call User microservice to get user details
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found while fetching properties");
        }

        UserDTO userDTO = userResponse.getBody();

        // Get properties added by this user
        List<PropertyDTO> propertyDTOs = propertyService.getPropertiesByUserId(userDTO.getId());

        return new ResponseEntity<>(propertyDTOs, HttpStatus.OK);
    }

    @GetMapping("/properties/user/{ownerId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<PropertyDTO>> getPropertiesAddedByOwnerId(@PathVariable Long ownerId) {
        List<PropertyDTO> properties = propertyService.getPropertiesByUserId(ownerId);
        return ResponseEntity.ok(properties);
    }

    @PostMapping("/properties")
    @PreAuthorize("hasRole('OWNER')")
    public ResponseEntity<PropertyDTO> addProperty(@RequestBody PropertyDTO propertyDTO) {
        propertyDTO.setId(null);

        // Get current user from authentication context
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found while adding property");
        }

        UserDTO userDTO = userResponse.getBody();
        propertyDTO.setAddedBy(userDTO.getId());

        PropertyDTO savedPropertyDTO = propertyService.save(propertyDTO);
        return new ResponseEntity<>(savedPropertyDTO, HttpStatus.CREATED);
    }

    @PutMapping("/properties")
    @PreAuthorize("hasRole('OWNER')")
    public PropertyDTO updateProperty(@RequestBody PropertyDTO propertyDTO) {

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ResponseEntity<UserDTO> userResponse = userServiceClient.getUserByUsername(username);

        if (!userResponse.getStatusCode().is2xxSuccessful() || userResponse.getBody() == null) {
            throw new RuntimeException("Current user not found while adding property");
        }

        UserDTO userDTO = userResponse.getBody();
        propertyDTO.setAddedBy(userDTO.getId());

        return propertyService.save(propertyDTO);
    }

    @PatchMapping("/properties/{propertyId}")
    @PreAuthorize("hasRole('OWNER')")
    public PropertyDTO patchProperty(@PathVariable int propertyId, @RequestBody Map<String, Object> patchPayload){
        PropertyDTO oldPropertyDTO = propertyService.findById(propertyId);
        PropertyDTO newProperty = apply(patchPayload, oldPropertyDTO);
        return propertyService.save(newProperty);
    }

    private PropertyDTO apply(Map<String, Object> patchPayload, PropertyDTO oldPropertyDTO) {
        ObjectNode propertyNode = objectMapper.convertValue(oldPropertyDTO, ObjectNode.class);
        ObjectNode patchNode = objectMapper.convertValue(patchPayload, ObjectNode.class);
        propertyNode.setAll(patchNode);
        return objectMapper.convertValue(propertyNode, PropertyDTO.class);
    }

    @DeleteMapping("/properties/{propertyId}")
    @PreAuthorize("hasAnyRole('OWNER','ADMIN')")
    public String deleteProperty(@PathVariable int propertyId) {
        PropertyDTO prop = propertyService.findById(propertyId);

        if(prop == null) {
            throw new RuntimeException("Property not found with id - " + propertyId);
        }

        propertyService.deleteById(propertyId);
        return "Deleted property with id - " + propertyId;
    }
}